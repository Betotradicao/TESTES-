import { Response } from 'express';
/**
 * Utilitário para tratar erros de banco de dados
 * Detecta problemas de conexão e tenta reconectar automaticamente
 */
export declare class DatabaseErrorHandler {
    /**
     * Verifica se o erro é relacionado à conexão do banco
     */
    static isConnectionError(error: any): boolean;
    /**
     * Tenta reconectar ao banco de dados
     */
    static tryReconnect(): Promise<boolean>;
    /**
     * Manipula erros de banco de dados em controllers
     */
    static handleError(error: any, res: Response, customMessage?: string): Promise<void>;
    /**
     * Wrapper para executar queries com retry automático
     */
    static executeWithRetry<T>(operation: () => Promise<T>, maxRetries?: number): Promise<T>;
}
//# sourceMappingURL=database-error-handler.d.ts.map