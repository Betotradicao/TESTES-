"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DailyVerificationCommand = void 0;
const database_1 = require("../config/database");
const bip_data_service_1 = require("../services/bip-data.service");
const whatsapp_service_1 = require("../services/whatsapp.service");
const bip_verification_service_1 = require("../services/bip-verification.service");
/**
 * Comando unificado de verificação diária
 *
 * Combina validação de vendas + verificação de bipagens + notificações
 * em um único fluxo otimizado
 */
class DailyVerificationCommand {
    static async execute(args) {
        const stats = {
            date: '',
            totalBipages: 0,
            bipsPending: 0,
            bipsToVerify: 0,
            bipsToNotify: 0,
            notifyBips: false,
            totalSales: 0,
            verifiedCount: 0,
            notVerifiedCount: 0,
            cancelledCount: 0,
            notifiedCount: 0,
            startTime: new Date()
        };
        try {
            console.log('🚀 Iniciando verificação diária unificada...\n');
            const parsedArgs = this.parseArguments(args);
            stats.notifyBips = parsedArgs.notify;
            this.validateArguments(parsedArgs);
            stats.date = parsedArgs.date;
            if (!database_1.AppDataSource.isInitialized) {
                await database_1.AppDataSource.initialize();
            }
            const sales = await bip_data_service_1.BipDataService.fetchSalesForDate(parsedArgs.date);
            stats.totalSales = sales.length;
            if (sales.length === 0) {
                this.printFinalReport(stats);
                return;
            }
            // Buscar TODAS as bipagens do dia (para matching com vendas)
            const bipages = await bip_data_service_1.BipDataService.fetchAllBipagesForDate(parsedArgs.date);
            stats.totalBipages = bipages.length;
            const activeProducts = await database_1.AppDataSource.query(`
        SELECT DISTINCT erp_product_id, id
        FROM products
        WHERE active = true
      `);
            const activeProductMap = new Map();
            activeProducts.forEach((product) => {
                activeProductMap.set(product.erp_product_id, product.id);
                const normalizedCode = String(parseInt(product.erp_product_id, 10));
                activeProductMap.set(normalizedCode, product.id);
            });
            const activeSales = sales.filter(sale => activeProductMap.has(sale.codProduto));
            const bipagesMap = new Map();
            bipages.forEach((bip) => {
                const normalizedProductId = String(parseInt(bip.product_id, 10));
                if (!bipagesMap.has(normalizedProductId)) {
                    bipagesMap.set(normalizedProductId, []);
                }
                bipagesMap.get(normalizedProductId).push(bip);
            });
            // FASE 3: PROCESSAR VENDAS
            await this.processSales(activeSales, bipagesMap, activeProductMap, parsedArgs.date, stats);
            // FASE 4: PROCESSAR BIPAGENS
            await this.processBipages(bipages, sales, parsedArgs.notify, stats);
            stats.endTime = new Date();
            this.printFinalReport(stats);
        }
        catch (error) {
            console.error('❌ Erro na execução:', error);
            stats.endTime = new Date();
            this.printFinalReport(stats);
            process.exit(1);
        }
    }
    /**
     * Processa bipagens: identifica as que não tiveram venda e notifica (se notify=true)
     */
    static async processBipages(allBipages, sales, notify, stats) {
        const pendingBipages = allBipages.filter(bip => bip.status === 'pending' && bip.notified_at === null);
        const verificationResult = bip_verification_service_1.BipVerificationService.processVerificationAndNotification(pendingBipages, sales);
        stats.bipsPending = pendingBipages.length;
        stats.bipsToVerify = verificationResult.to_verify.length;
        stats.bipsToNotify = verificationResult.to_notify.length;
        if (verificationResult.to_verify.length > 0) {
            await bip_verification_service_1.BipVerificationService.processVerifications(verificationResult.to_verify);
        }
        if (notify && verificationResult.to_notify.length > 0) {
            const notificationResults = await whatsapp_service_1.WhatsAppService.sendMultipleNotifications(verificationResult.to_notify);
            stats.notifiedCount = notificationResults.success;
            if (notificationResults.successfulBips.length > 0) {
                await bip_verification_service_1.BipVerificationService.processNotifications(notificationResults.successfulBips);
            }
        }
        stats.endTimeBips = new Date();
    }
    /**
     * Processa vendas: faz matching com bipagens e salva em sells
     */
    static async processSales(activeSales, bipagesMap, activeProductMap, date, stats) {
        const sellsToInsert = [];
        const positiveSalesMap = new Map();
        for (const sale of activeSales) {
            const activatedProductId = activeProductMap.get(sale.codProduto);
            const saleValueCents = Math.round(sale.valTotalProduto * 100);
            const normalizedProductCode = String(parseInt(sale.codProduto, 10));
            const isCancellation = saleValueCents < 0;
            let matchedBip = null;
            let status = 'not_verified';
            if (isCancellation) {
                const positiveValueCents = Math.abs(saleValueCents);
                const positiveWeight = Math.abs(sale.qtdTotalProduto);
                const saleKey = `${sale.codProduto}_${positiveValueCents}_${positiveWeight}`;
                const originalSale = positiveSalesMap.get(saleKey);
                if (originalSale && originalSale.bip_id) {
                    matchedBip = { id: originalSale.bip_id };
                    status = 'cancelled';
                }
                else {
                    status = 'cancelled';
                }
                stats.cancelledCount++;
            }
            else {
                const productBipages = bipagesMap.get(normalizedProductCode) || [];
                const PRICE_TOLERANCE_CENTS = 3;
                for (const bip of productBipages) {
                    const priceDifference = Math.abs(bip.bip_price_cents - saleValueCents);
                    if (priceDifference <= PRICE_TOLERANCE_CENTS) {
                        matchedBip = bip;
                        break;
                    }
                }
                status = matchedBip ? 'verified' : 'not_verified';
                if (matchedBip) {
                    stats.verifiedCount++;
                }
                else {
                    stats.notVerifiedCount++;
                }
                const saleKey = `${sale.codProduto}_${saleValueCents}_${sale.qtdTotalProduto}`;
                positiveSalesMap.set(saleKey, {
                    cupom_fiscal: sale.numCupomFiscal,
                    bip_id: matchedBip ? matchedBip.id : null
                });
            }
            // Formata a data com timezone do Brasil para evitar conversão incorreta
            const sellDate = sale.dataHoraVenda
                ? `${sale.dataHoraVenda}-03:00` // Adiciona timezone do Brasil (UTC-3)
                : `${date} 00:00:00-03:00`;
            const sellRecord = {
                activated_product_id: activatedProductId,
                product_id: sale.codProduto,
                product_description: sale.desProduto,
                sell_date: sellDate,
                sell_value_cents: saleValueCents,
                product_weight: sale.qtdTotalProduto,
                bip_id: matchedBip ? matchedBip.id : null,
                num_cupom_fiscal: sale.numCupomFiscal,
                point_of_sale_code: sale.codCaixa || null,
                status: status,
                discount_cents: sale.descontoAplicado ? Math.round(sale.descontoAplicado * 100) : 0
            };
            sellsToInsert.push(sellRecord);
        }
        if (sellsToInsert.length > 0) {
            const values = sellsToInsert.map(record => `(${record.activated_product_id}, '${record.product_id}', '${record.product_description.replace(/'/g, "''")}', '${record.sell_date}', ${record.sell_value_cents}, ${record.product_weight}, ${record.bip_id || 'NULL'}, '${record.num_cupom_fiscal}', ${record.point_of_sale_code || 'NULL'}, '${record.status}', ${record.discount_cents})`).join(',');
            await database_1.AppDataSource.query(`
          INSERT INTO sells (activated_product_id, product_id, product_description, sell_date, sell_value_cents, product_weight, bip_id, num_cupom_fiscal, point_of_sale_code, status, discount_cents)
          VALUES ${values}
          ON CONFLICT (product_id, product_weight, num_cupom_fiscal) DO NOTHING
        `);
        }
        const cancelledSalesWithBips = sellsToInsert.filter(s => s.status === 'cancelled' && s.bip_id);
        if (cancelledSalesWithBips.length > 0) {
            const bipIdsToCancel = cancelledSalesWithBips.map(s => s.bip_id);
            await database_1.AppDataSource.query(`
          UPDATE bips
          SET status = 'cancelled'
          WHERE id = ANY($1::int[])
        `, [bipIdsToCancel]);
        }
        stats.endTimeSells = new Date();
    }
    static parseArguments(args) {
        const parsedArgs = {
            notify: false,
            date: new Date().toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' })
                .split('/').reverse().join('-'),
            runYesterday: false
        };
        for (let i = 0; i < args.length; i++) {
            const arg = args[i];
            if (arg === '--notify') {
                const value = args[i + 1];
                parsedArgs.notify = value === 'true';
                i++;
            }
            if (arg === '--date') {
                parsedArgs.date = args[i + 1];
                i++;
            }
            if (arg === '--runYesterday') {
                parsedArgs.runYesterday = true;
                parsedArgs.notify = true;
                const yesterday = new Date();
                yesterday.setDate(yesterday.getDate() - 1);
                parsedArgs.date = yesterday.toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' })
                    .split('/').reverse().join('-');
            }
        }
        return parsedArgs;
    }
    static validateArguments(args) {
        if (args.date) {
            const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!dateRegex.test(args.date)) {
                throw new Error('Formato de data inválido. Use YYYY-MM-DD');
            }
        }
    }
    static printFinalReport(stats) {
        if (stats.endTimeSells) {
            const ms = stats.endTimeSells.getTime() - stats.startTime.getTime();
            const minutes = Math.floor(ms / 60000);
            const seconds = Math.floor((ms % 60000) / 1000);
            stats.executionTimeSells = `${minutes}m ${seconds}s`;
        }
        if (stats.endTimeBips) {
            const ms = stats.endTimeBips.getTime() - stats.startTime.getTime();
            const minutes = Math.floor(ms / 60000);
            const seconds = Math.floor((ms % 60000) / 1000);
            stats.executionTimeBips = `${minutes}m ${seconds}s`;
        }
        if (stats.endTime) {
            const ms = stats.endTime.getTime() - stats.startTime.getTime();
            const minutes = Math.floor(ms / 60000);
            const seconds = Math.floor((ms % 60000) / 1000);
            stats.executionTime = `${minutes}m ${seconds}s`;
        }
        console.log('='.repeat(60));
        console.log('📊 RELATÓRIO DE VERIFICAÇÃO DIÁRIA');
        console.log('='.repeat(60));
        console.log(`📅 Data: ${stats.date} `);
        console.log(`\n🛒 Vendas ERP: ${stats.totalSales}`);
        console.log(`✅ Verificadas: ${stats.verifiedCount}`);
        console.log(`⚠️  Não verificadas: ${stats.notVerifiedCount}`);
        console.log(`🚫 Canceladas: ${stats.cancelledCount}`);
        if (stats.executionTimeSells) {
            console.log(`⏱️  Tempo vendas: ${stats.executionTimeSells}`);
        }
        console.log(`\n📱 Total de bipagens: ${stats.totalBipages}`);
        console.log(`📱 Bipagens pendente: ${stats.bipsPending}`);
        console.log(`⚙️ Notificar: ${stats.notifyBips ? 'Sim' : 'Não'}`);
        console.log(`✅ Bipagens para verificar: ${stats.bipsToVerify}`);
        console.log(`📢 Bipagens para notificar: ${stats.bipsToNotify}`);
        if (stats.executionTimeBips) {
            console.log(`⏱️  Tempo bipagens: ${stats.executionTimeBips}`);
        }
        if (stats.executionTime) {
            console.log(`\n⏱️  Tempo total: ${stats.executionTime}`);
        }
        console.log('='.repeat(60));
    }
}
exports.DailyVerificationCommand = DailyVerificationCommand;
if (require.main === module) {
    const args = process.argv.slice(2);
    DailyVerificationCommand.execute(args)
        .then(() => process.exit(0))
        .catch(() => process.exit(1));
}
//# sourceMappingURL=daily-verification.command.js.map