export declare class CheckLastBipCommand {
    /**
     * Verifica a última bipagem e envia alerta se necessário
     * Funciona apenas entre 7h30 e 21h30 (horário de São Paulo)
     */
    static execute(): Promise<void>;
    /**
     * Envia alerta via WhatsApp
     */
    private static sendAlert;
}
//# sourceMappingURL=check-last-bip.command.d.ts.map