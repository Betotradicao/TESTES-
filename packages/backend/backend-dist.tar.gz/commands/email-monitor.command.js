"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailMonitorCommand = void 0;
const database_1 = require("../config/database");
const email_monitor_service_1 = require("../services/email-monitor.service");
class EmailMonitorCommand {
    /**
     * Verifica novos emails de DVR e processa
     */
    static async execute() {
        console.log('📧 Verificando emails de DVR...');
        try {
            // Inicializar conexão com banco se necessário
            if (!database_1.AppDataSource.isInitialized) {
                await database_1.AppDataSource.initialize();
                database_1.AppDataSource.setOptions({ logging: false }); // Desabilitar logs SQL
            }
            // Verificar novos emails
            await email_monitor_service_1.EmailMonitorService.checkNewEmails();
            console.log('✅ Verificação de emails concluída');
        }
        catch (error) {
            console.error('❌ Erro ao verificar emails:', error);
            throw error;
        }
        finally {
            if (database_1.AppDataSource.isInitialized) {
                await database_1.AppDataSource.destroy();
            }
        }
    }
}
exports.EmailMonitorCommand = EmailMonitorCommand;
// Executar o comando se chamado diretamente
if (require.main === module) {
    EmailMonitorCommand.execute()
        .then(() => {
        console.log('✅ Comando de email monitor concluído');
        process.exit(0);
    })
        .catch((error) => {
        console.error('❌ Erro na execução:', error);
        process.exit(1);
    });
}
//# sourceMappingURL=email-monitor.command.js.map