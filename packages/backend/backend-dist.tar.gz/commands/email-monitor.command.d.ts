export declare class EmailMonitorCommand {
    /**
     * Verifica novos emails de DVR e processa
     */
    static execute(): Promise<void>;
}
//# sourceMappingURL=email-monitor.command.d.ts.map