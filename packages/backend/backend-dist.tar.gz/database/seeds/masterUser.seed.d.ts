import { DataSource } from 'typeorm';
/**
 * Seed do usuário master
 * Cria automaticamente:
 * - Usuário master "Roberto" (sem empresa vinculada)
 * - Configurações essenciais do sistema
 *
 * A empresa será criada no First Setup pelo cliente
 */
export declare function seedMasterUser(dataSource: DataSource): Promise<void>;
//# sourceMappingURL=masterUser.seed.d.ts.map