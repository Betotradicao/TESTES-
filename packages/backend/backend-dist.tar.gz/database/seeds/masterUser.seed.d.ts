import { DataSource } from 'typeorm';
/**
 * Seed completo do sistema
 * Cria automaticamente:
 * - Empresa padrão
 * - Usuário master "Beto"
 * - Configurações essenciais do sistema
 */
export declare function seedMasterUser(dataSource: DataSource): Promise<void>;
//# sourceMappingURL=masterUser.seed.d.ts.map