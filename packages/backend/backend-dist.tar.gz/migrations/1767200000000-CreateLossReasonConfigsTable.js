"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateLossReasonConfigsTable1767200000000 = void 0;
const typeorm_1 = require("typeorm");
class CreateLossReasonConfigsTable1767200000000 {
    async up(queryRunner) {
        await queryRunner.createTable(new typeorm_1.Table({
            name: 'loss_reason_configs',
            columns: [
                {
                    name: 'id',
                    type: 'int',
                    isPrimary: true,
                    isGenerated: true,
                    generationStrategy: 'increment',
                },
                {
                    name: 'company_id',
                    type: 'uuid',
                    isNullable: false,
                },
                {
                    name: 'motivo',
                    type: 'text',
                    isNullable: false,
                },
                {
                    name: 'ignorar_calculo',
                    type: 'boolean',
                    default: false,
                },
                {
                    name: 'created_at',
                    type: 'timestamp',
                    default: 'now()',
                },
                {
                    name: 'updated_at',
                    type: 'timestamp',
                    default: 'now()',
                },
            ],
        }), true);
        await queryRunner.createForeignKey('loss_reason_configs', new typeorm_1.TableForeignKey({
            columnNames: ['company_id'],
            referencedColumnNames: ['id'],
            referencedTableName: 'companies',
            onDelete: 'CASCADE',
        }));
        // Criar índice único para company_id + motivo
        await queryRunner.query(`
      CREATE UNIQUE INDEX idx_loss_reason_configs_company_motivo 
      ON loss_reason_configs (company_id, motivo);
    `);
    }
    async down(queryRunner) {
        await queryRunner.dropTable('loss_reason_configs');
    }
}
exports.CreateLossReasonConfigsTable1767200000000 = CreateLossReasonConfigsTable1767200000000;
//# sourceMappingURL=1767200000000-CreateLossReasonConfigsTable.js.map