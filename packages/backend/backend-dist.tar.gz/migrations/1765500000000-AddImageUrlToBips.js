"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddImageUrlToBips1765500000000 = void 0;
const typeorm_1 = require("typeorm");
class AddImageUrlToBips1765500000000 {
    async up(queryRunner) {
        await queryRunner.addColumn('bips', new typeorm_1.TableColumn({
            name: 'image_url',
            type: 'varchar',
            length: '500',
            isNullable: true,
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('bips', 'image_url');
    }
}
exports.AddImageUrlToBips1765500000000 = AddImageUrlToBips1765500000000;
//# sourceMappingURL=1765500000000-AddImageUrlToBips.js.map