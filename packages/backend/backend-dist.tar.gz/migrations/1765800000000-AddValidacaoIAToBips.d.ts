import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddValidacaoIAToBips1765800000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1765800000000-AddValidacaoIAToBips.d.ts.map