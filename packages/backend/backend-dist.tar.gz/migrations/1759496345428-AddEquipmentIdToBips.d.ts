import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddEquipmentIdToBips1759496345428 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1759496345428-AddEquipmentIdToBips.d.ts.map