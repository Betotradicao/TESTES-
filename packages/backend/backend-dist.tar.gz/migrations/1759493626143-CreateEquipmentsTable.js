"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateEquipmentsTable1759493626143 = void 0;
class CreateEquipmentsTable1759493626143 {
    async up(queryRunner) {
        await queryRunner.query(`
            CREATE TABLE IF NOT EXISTS "equipments" (
                "id" SERIAL PRIMARY KEY,
                "color_hash" varchar(7) NOT NULL DEFAULT '#000000',
                "scanner_machine_id" varchar(255) NOT NULL,
                "machine_id" varchar(255) NOT NULL,
                "description" text,
                "sector_id" integer,
                "active" boolean NOT NULL DEFAULT true,
                "created_at" TIMESTAMP NOT NULL DEFAULT now(),
                "updated_at" TIMESTAMP NOT NULL DEFAULT now(),
                CONSTRAINT "UQ_equipments_scanner_machine_id" UNIQUE ("scanner_machine_id"),
                CONSTRAINT "FK_equipments_sector_id" FOREIGN KEY ("sector_id") REFERENCES "sectors"("id") ON DELETE SET NULL
            )
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_equipments_scanner_machine_id" ON "equipments" ("scanner_machine_id")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_equipments_machine_id" ON "equipments" ("machine_id")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_equipments_sector_id" ON "equipments" ("sector_id")
        `);
        await queryRunner.query(`
            CREATE INDEX "IDX_equipments_active" ON "equipments" ("active")
        `);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP INDEX IF EXISTS "IDX_equipments_active"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "IDX_equipments_sector_id"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "IDX_equipments_machine_id"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "IDX_equipments_scanner_machine_id"`);
        await queryRunner.query(`DROP TABLE IF EXISTS "equipments"`);
    }
}
exports.CreateEquipmentsTable1759493626143 = CreateEquipmentsTable1759493626143;
//# sourceMappingURL=1759493626143-CreateEquipmentsTable.js.map