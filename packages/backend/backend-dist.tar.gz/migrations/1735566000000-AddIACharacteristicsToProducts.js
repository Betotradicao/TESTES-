"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddIACharacteristicsToProducts1735566000000 = void 0;
class AddIACharacteristicsToProducts1735566000000 {
    async up(queryRunner) {
        await queryRunner.query(`
            ALTER TABLE "products"
            ADD COLUMN IF NOT EXISTS "foto_referencia" TEXT,
            ADD COLUMN IF NOT EXISTS "coloracao" VARCHAR(50),
            ADD COLUMN IF NOT EXISTS "formato" VARCHAR(50),
            ADD COLUMN IF NOT EXISTS "gordura_visivel" VARCHAR(50),
            ADD COLUMN IF NOT EXISTS "presenca_osso" BOOLEAN,
            ADD COLUMN IF NOT EXISTS "peso_min_kg" DECIMAL(10,3),
            ADD COLUMN IF NOT EXISTS "peso_max_kg" DECIMAL(10,3),
            ADD COLUMN IF NOT EXISTS "posicao_balcao" JSONB
        `);
    }
    async down(queryRunner) {
        await queryRunner.query(`
            ALTER TABLE "products"
            DROP COLUMN IF EXISTS "foto_referencia",
            DROP COLUMN IF EXISTS "coloracao",
            DROP COLUMN IF EXISTS "formato",
            DROP COLUMN IF EXISTS "gordura_visivel",
            DROP COLUMN IF EXISTS "presenca_osso",
            DROP COLUMN IF EXISTS "peso_min_kg",
            DROP COLUMN IF EXISTS "peso_max_kg",
            DROP COLUMN IF EXISTS "posicao_balcao"
        `);
    }
}
exports.AddIACharacteristicsToProducts1735566000000 = AddIACharacteristicsToProducts1735566000000;
//# sourceMappingURL=1735566000000-AddIACharacteristicsToProducts.js.map