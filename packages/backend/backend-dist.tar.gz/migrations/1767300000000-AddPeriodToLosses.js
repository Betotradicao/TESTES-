"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddPeriodToLosses1767300000000 = void 0;
const typeorm_1 = require("typeorm");
class AddPeriodToLosses1767300000000 {
    async up(queryRunner) {
        await queryRunner.addColumn('losses', new typeorm_1.TableColumn({
            name: 'data_inicio_periodo',
            type: 'date',
            isNullable: true,
        }));
        await queryRunner.addColumn('losses', new typeorm_1.TableColumn({
            name: 'data_fim_periodo',
            type: 'date',
            isNullable: true,
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('losses', 'data_fim_periodo');
        await queryRunner.dropColumn('losses', 'data_inicio_periodo');
    }
}
exports.AddPeriodToLosses1767300000000 = AddPeriodToLosses1767300000000;
//# sourceMappingURL=1767300000000-AddPeriodToLosses.js.map