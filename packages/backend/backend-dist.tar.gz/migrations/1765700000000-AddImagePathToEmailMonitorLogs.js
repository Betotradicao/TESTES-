"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddImagePathToEmailMonitorLogs1765700000000 = void 0;
const typeorm_1 = require("typeorm");
class AddImagePathToEmailMonitorLogs1765700000000 {
    async up(queryRunner) {
        const table = await queryRunner.getTable("email_monitor_logs");
        const imagePathColumn = table?.findColumnByName("image_path");
        if (!imagePathColumn) {
            await queryRunner.addColumn("email_monitor_logs", new typeorm_1.TableColumn({
                name: "image_path",
                type: "varchar",
                length: "500",
                isNullable: true
            }));
        }
    }
    async down(queryRunner) {
        const table = await queryRunner.getTable("email_monitor_logs");
        const imagePathColumn = table?.findColumnByName("image_path");
        if (imagePathColumn) {
            await queryRunner.dropColumn("email_monitor_logs", "image_path");
        }
    }
}
exports.AddImagePathToEmailMonitorLogs1765700000000 = AddImagePathToEmailMonitorLogs1765700000000;
//# sourceMappingURL=1765700000000-AddImagePathToEmailMonitorLogs.js.map