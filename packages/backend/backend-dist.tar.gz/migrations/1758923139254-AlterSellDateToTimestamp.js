"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlterSellDateToTimestamp1758923139254 = void 0;
class AlterSellDateToTimestamp1758923139254 {
    async up(queryRunner) {
        // Alterar o tipo da coluna sell_date de DATE para TIMESTAMP
        await queryRunner.query(`
            ALTER TABLE "sells"
            ALTER COLUMN "sell_date" TYPE TIMESTAMP
            USING "sell_date"::timestamp
        `);
    }
    async down(queryRunner) {
        // Reverter para DATE
        await queryRunner.query(`
            ALTER TABLE "sells"
            ALTER COLUMN "sell_date" TYPE DATE
            USING "sell_date"::date
        `);
    }
}
exports.AlterSellDateToTimestamp1758923139254 = AlterSellDateToTimestamp1758923139254;
//# sourceMappingURL=1758923139254-AlterSellDateToTimestamp.js.map