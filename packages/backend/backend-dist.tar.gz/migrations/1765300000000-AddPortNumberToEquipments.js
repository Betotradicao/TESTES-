"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddPortNumberToEquipments1765300000000 = void 0;
const typeorm_1 = require("typeorm");
class AddPortNumberToEquipments1765300000000 {
    async up(queryRunner) {
        await queryRunner.addColumn('equipments', new typeorm_1.TableColumn({
            name: 'port_number',
            type: 'varchar',
            length: '50',
            isNullable: true,
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('equipments', 'port_number');
    }
}
exports.AddPortNumberToEquipments1765300000000 = AddPortNumberToEquipments1765300000000;
//# sourceMappingURL=1765300000000-AddPortNumberToEquipments.js.map