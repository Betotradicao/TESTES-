"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddPedidoToRuptureSurveyItems1735720000000 = void 0;
const typeorm_1 = require("typeorm");
class AddPedidoToRuptureSurveyItems1735720000000 {
    async up(queryRunner) {
        await queryRunner.addColumn('rupture_survey_items', new typeorm_1.TableColumn({
            name: 'tem_pedido',
            type: 'varchar',
            length: '3',
            isNullable: true,
            comment: 'Indica se existe pedido em aberto para o produto (Sim/Não)',
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('rupture_survey_items', 'tem_pedido');
    }
}
exports.AddPedidoToRuptureSurveyItems1735720000000 = AddPedidoToRuptureSurveyItems1735720000000;
//# sourceMappingURL=1735720000000-AddPedidoToRuptureSurveyItems.js.map