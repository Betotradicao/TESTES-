"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddNumCupomFiscalToSells1758161394993 = void 0;
class AddNumCupomFiscalToSells1758161394993 {
    async up(queryRunner) {
        await queryRunner.query(`
            ALTER TABLE "sells"
            ADD COLUMN "num_cupom_fiscal" INTEGER NULL
        `);
    }
    async down(queryRunner) {
        await queryRunner.query(`
            ALTER TABLE "sells"
            DROP COLUMN "num_cupom_fiscal"
        `);
    }
}
exports.AddNumCupomFiscalToSells1758161394993 = AddNumCupomFiscalToSells1758161394993;
//# sourceMappingURL=1758161394993-AddNumCupomFiscalToSells.js.map