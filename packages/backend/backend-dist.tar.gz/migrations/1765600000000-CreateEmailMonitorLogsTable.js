"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateEmailMonitorLogsTable1765600000000 = void 0;
const typeorm_1 = require("typeorm");
class CreateEmailMonitorLogsTable1765600000000 {
    async up(queryRunner) {
        await queryRunner.createTable(new typeorm_1.Table({
            name: "email_monitor_logs",
            columns: [
                {
                    name: "id",
                    type: "uuid",
                    isPrimary: true,
                    generationStrategy: "uuid",
                    default: "uuid_generate_v4()"
                },
                {
                    name: "email_subject",
                    type: "varchar",
                    length: "255"
                },
                {
                    name: "sender",
                    type: "varchar",
                    length: "255"
                },
                {
                    name: "email_body",
                    type: "text",
                    isNullable: true
                },
                {
                    name: "status",
                    type: "varchar",
                    length: "100"
                },
                {
                    name: "error_message",
                    type: "text",
                    isNullable: true
                },
                {
                    name: "has_attachment",
                    type: "boolean",
                    default: false
                },
                {
                    name: "whatsapp_group_id",
                    type: "varchar",
                    length: "255",
                    isNullable: true
                },
                {
                    name: "processed_at",
                    type: "timestamp",
                    default: "now()"
                }
            ]
        }), true);
    }
    async down(queryRunner) {
        await queryRunner.dropTable("email_monitor_logs");
    }
}
exports.CreateEmailMonitorLogsTable1765600000000 = CreateEmailMonitorLogsTable1765600000000;
//# sourceMappingURL=1765600000000-CreateEmailMonitorLogsTable.js.map