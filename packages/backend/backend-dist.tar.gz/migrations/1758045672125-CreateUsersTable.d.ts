import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateUsersTable1758045672125 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1758045672125-CreateUsersTable.d.ts.map