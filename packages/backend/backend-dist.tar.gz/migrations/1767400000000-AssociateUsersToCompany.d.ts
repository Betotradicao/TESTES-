import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AssociateUsersToCompany1767400000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1767400000000-AssociateUsersToCompany.d.ts.map