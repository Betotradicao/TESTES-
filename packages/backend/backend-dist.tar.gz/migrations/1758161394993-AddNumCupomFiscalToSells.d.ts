import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddNumCupomFiscalToSells1758161394993 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1758161394993-AddNumCupomFiscalToSells.d.ts.map