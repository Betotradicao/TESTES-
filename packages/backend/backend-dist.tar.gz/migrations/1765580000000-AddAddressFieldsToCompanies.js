"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddAddressFieldsToCompanies1765580000000 = void 0;
const typeorm_1 = require("typeorm");
class AddAddressFieldsToCompanies1765580000000 {
    async up(queryRunner) {
        const table = await queryRunner.getTable('companies');
        if (!table) {
            throw new Error('Tabela companies não encontrada');
        }
        // Adicionar campos de endereço individuais
        if (!table.findColumnByName('cep')) {
            await queryRunner.addColumn('companies', new typeorm_1.TableColumn({
                name: 'cep',
                type: 'varchar',
                length: '9',
                isNullable: true
            }));
        }
        if (!table.findColumnByName('rua')) {
            await queryRunner.addColumn('companies', new typeorm_1.TableColumn({
                name: 'rua',
                type: 'varchar',
                length: '255',
                isNullable: true
            }));
        }
        if (!table.findColumnByName('numero')) {
            await queryRunner.addColumn('companies', new typeorm_1.TableColumn({
                name: 'numero',
                type: 'varchar',
                length: '20',
                isNullable: true
            }));
        }
        if (!table.findColumnByName('complemento')) {
            await queryRunner.addColumn('companies', new typeorm_1.TableColumn({
                name: 'complemento',
                type: 'varchar',
                length: '100',
                isNullable: true
            }));
        }
        if (!table.findColumnByName('bairro')) {
            await queryRunner.addColumn('companies', new typeorm_1.TableColumn({
                name: 'bairro',
                type: 'varchar',
                length: '100',
                isNullable: true
            }));
        }
        if (!table.findColumnByName('cidade')) {
            await queryRunner.addColumn('companies', new typeorm_1.TableColumn({
                name: 'cidade',
                type: 'varchar',
                length: '100',
                isNullable: true
            }));
        }
        if (!table.findColumnByName('estado')) {
            await queryRunner.addColumn('companies', new typeorm_1.TableColumn({
                name: 'estado',
                type: 'varchar',
                length: '2',
                isNullable: true
            }));
        }
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('companies', 'cep');
        await queryRunner.dropColumn('companies', 'rua');
        await queryRunner.dropColumn('companies', 'numero');
        await queryRunner.dropColumn('companies', 'complemento');
        await queryRunner.dropColumn('companies', 'bairro');
        await queryRunner.dropColumn('companies', 'cidade');
        await queryRunner.dropColumn('companies', 'estado');
    }
}
exports.AddAddressFieldsToCompanies1765580000000 = AddAddressFieldsToCompanies1765580000000;
//# sourceMappingURL=1765580000000-AddAddressFieldsToCompanies.js.map