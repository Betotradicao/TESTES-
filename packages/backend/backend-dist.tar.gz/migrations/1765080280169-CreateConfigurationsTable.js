"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateConfigurationsTable1765080280169 = void 0;
const typeorm_1 = require("typeorm");
class CreateConfigurationsTable1765080280169 {
    async up(queryRunner) {
        await queryRunner.createTable(new typeorm_1.Table({
            name: "configurations",
            columns: [
                {
                    name: "id",
                    type: "uuid",
                    isPrimary: true,
                    generationStrategy: "uuid",
                    default: "uuid_generate_v4()"
                },
                {
                    name: "key",
                    type: "varchar",
                    isUnique: true
                },
                {
                    name: "value",
                    type: "text",
                    isNullable: true
                },
                {
                    name: "encrypted",
                    type: "boolean",
                    default: false
                },
                {
                    name: "created_at",
                    type: "timestamp",
                    default: "now()"
                },
                {
                    name: "updated_at",
                    type: "timestamp",
                    default: "now()"
                }
            ]
        }), true);
    }
    async down(queryRunner) {
        await queryRunner.dropTable("configurations");
    }
}
exports.CreateConfigurationsTable1765080280169 = CreateConfigurationsTable1765080280169;
//# sourceMappingURL=1765080280169-CreateConfigurationsTable.js.map