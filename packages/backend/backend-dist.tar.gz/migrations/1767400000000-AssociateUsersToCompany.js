"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssociateUsersToCompany1767400000000 = void 0;
class AssociateUsersToCompany1767400000000 {
    async up(queryRunner) {
        // Associar todos os usuários sem empresa à primeira empresa disponível
        await queryRunner.query(`
            UPDATE users
            SET company_id = (SELECT id FROM companies ORDER BY created_at ASC LIMIT 1)
            WHERE company_id IS NULL
            AND EXISTS (SELECT 1 FROM companies LIMIT 1)
        `);
        console.log('✅ Usuários associados automaticamente à empresa');
    }
    async down(queryRunner) {
        // Não precisa reverter - mantém os usuários associados
        console.log('⏭️  Rollback não necessário - mantendo associações');
    }
}
exports.AssociateUsersToCompany1767400000000 = AssociateUsersToCompany1767400000000;
//# sourceMappingURL=1767400000000-AssociateUsersToCompany.js.map