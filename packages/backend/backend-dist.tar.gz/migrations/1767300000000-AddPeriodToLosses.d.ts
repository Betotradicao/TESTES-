import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddPeriodToLosses1767300000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1767300000000-AddPeriodToLosses.d.ts.map