import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddPeriodToLosses1735668900000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=AddPeriodToLosses.d.ts.map