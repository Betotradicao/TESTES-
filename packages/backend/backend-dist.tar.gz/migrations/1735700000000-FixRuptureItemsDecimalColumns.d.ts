import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class FixRuptureItemsDecimalColumns1735700000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1735700000000-FixRuptureItemsDecimalColumns.d.ts.map