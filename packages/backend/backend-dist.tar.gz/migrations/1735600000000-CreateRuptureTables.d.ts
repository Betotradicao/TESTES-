import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateRuptureTables1735600000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1735600000000-CreateRuptureTables.d.ts.map