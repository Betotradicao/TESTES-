import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddImagePathToEmailMonitorLogs1765700000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1765700000000-AddImagePathToEmailMonitorLogs.d.ts.map