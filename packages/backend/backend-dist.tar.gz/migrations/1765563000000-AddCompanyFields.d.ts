import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class AddCompanyFields1765563000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1765563000000-AddCompanyFields.d.ts.map