import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateEmployeesTable1759500000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1759500000000-CreateEmployeesTable.d.ts.map