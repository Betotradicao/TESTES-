import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddIACharacteristicsToProducts1735566000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1735566000000-AddIACharacteristicsToProducts.d.ts.map