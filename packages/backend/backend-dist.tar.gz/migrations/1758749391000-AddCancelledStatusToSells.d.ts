import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddCancelledStatusToSells1758749391000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1758749391000-AddCancelledStatusToSells.d.ts.map