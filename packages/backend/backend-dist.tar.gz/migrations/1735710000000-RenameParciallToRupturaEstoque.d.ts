import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class RenameParciallToRupturaEstoque1735710000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1735710000000-RenameParciallToRupturaEstoque.d.ts.map