import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateLabelAuditTables1767733000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1767733000000-CreateLabelAuditTables.d.ts.map