"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FixRuptureItemsDecimalColumns1735700000000 = void 0;
class FixRuptureItemsDecimalColumns1735700000000 {
    async up(queryRunner) {
        // Alterar cobertura_dias de int para decimal
        await queryRunner.query(`
      ALTER TABLE rupture_survey_items
      ALTER COLUMN cobertura_dias TYPE DECIMAL(10,2)
    `);
        // Alterar qtd_embalagem de int para decimal
        await queryRunner.query(`
      ALTER TABLE rupture_survey_items
      ALTER COLUMN qtd_embalagem TYPE DECIMAL(10,2)
    `);
    }
    async down(queryRunner) {
        await queryRunner.query(`
      ALTER TABLE rupture_survey_items
      ALTER COLUMN cobertura_dias TYPE INT
    `);
        await queryRunner.query(`
      ALTER TABLE rupture_survey_items
      ALTER COLUMN qtd_embalagem TYPE INT
    `);
    }
}
exports.FixRuptureItemsDecimalColumns1735700000000 = FixRuptureItemsDecimalColumns1735700000000;
//# sourceMappingURL=1735700000000-FixRuptureItemsDecimalColumns.js.map