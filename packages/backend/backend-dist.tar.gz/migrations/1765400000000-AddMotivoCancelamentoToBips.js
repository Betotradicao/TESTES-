"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddMotivoCancelamentoToBips1765400000000 = void 0;
const typeorm_1 = require("typeorm");
class AddMotivoCancelamentoToBips1765400000000 {
    async up(queryRunner) {
        // Adicionar coluna motivo_cancelamento
        await queryRunner.addColumn('bips', new typeorm_1.TableColumn({
            name: 'motivo_cancelamento',
            type: 'varchar',
            length: '50',
            isNullable: true,
            comment: 'Motivo do cancelamento da bipagem'
        }));
        console.log('✅ Coluna motivo_cancelamento adicionada à tabela bips');
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('bips', 'motivo_cancelamento');
        console.log('✅ Coluna motivo_cancelamento removida da tabela bips');
    }
}
exports.AddMotivoCancelamentoToBips1765400000000 = AddMotivoCancelamentoToBips1765400000000;
//# sourceMappingURL=1765400000000-AddMotivoCancelamentoToBips.js.map