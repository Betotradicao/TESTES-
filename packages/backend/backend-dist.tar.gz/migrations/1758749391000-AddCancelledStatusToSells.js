"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddCancelledStatusToSells1758749391000 = void 0;
class AddCancelledStatusToSells1758749391000 {
    async up(queryRunner) {
        // Drop the old constraint
        await queryRunner.query(`
            ALTER TABLE "sells"
            DROP CONSTRAINT IF EXISTS "sells_status_check"
        `);
        // Add new constraint with 'cancelled' status
        await queryRunner.query(`
            ALTER TABLE "sells"
            ADD CONSTRAINT "sells_status_check"
            CHECK (status IN ('verified', 'notified', 'cancelled'))
        `);
    }
    async down(queryRunner) {
        // Drop the new constraint
        await queryRunner.query(`
            ALTER TABLE "sells"
            DROP CONSTRAINT IF EXISTS "sells_status_check"
        `);
        // Restore old constraint without 'cancelled' status
        await queryRunner.query(`
            ALTER TABLE "sells"
            ADD CONSTRAINT "sells_status_check"
            CHECK (status IN ('verified', 'notified'))
        `);
        // Update any 'cancelled' records to 'notified' before applying the constraint
        await queryRunner.query(`
            UPDATE "sells"
            SET status = 'notified'
            WHERE status = 'cancelled'
        `);
    }
}
exports.AddCancelledStatusToSells1758749391000 = AddCancelledStatusToSells1758749391000;
//# sourceMappingURL=1758749391000-AddCancelledStatusToSells.js.map