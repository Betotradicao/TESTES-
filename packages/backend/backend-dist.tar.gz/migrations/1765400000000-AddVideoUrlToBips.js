"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddVideoUrlToBips1765400000000 = void 0;
const typeorm_1 = require("typeorm");
class AddVideoUrlToBips1765400000000 {
    async up(queryRunner) {
        await queryRunner.addColumn('bips', new typeorm_1.TableColumn({
            name: 'video_url',
            type: 'varchar',
            length: '500',
            isNullable: true,
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('bips', 'video_url');
    }
}
exports.AddVideoUrlToBips1765400000000 = AddVideoUrlToBips1765400000000;
//# sourceMappingURL=1765400000000-AddVideoUrlToBips.js.map