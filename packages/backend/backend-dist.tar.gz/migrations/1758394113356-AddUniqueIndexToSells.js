"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddUniqueIndexToSells1758394113356 = void 0;
class AddUniqueIndexToSells1758394113356 {
    async up(queryRunner) {
        // Criar índice único para prevenir duplicações
        await queryRunner.query(`
            CREATE UNIQUE INDEX "IDX_sells_unique_sale"
            ON "sells" ("product_id", "product_weight", "num_cupom_fiscal")
        `);
    }
    async down(queryRunner) {
        // Remover índice único
        await queryRunner.query(`DROP INDEX "IDX_sells_unique_sale"`);
    }
}
exports.AddUniqueIndexToSells1758394113356 = AddUniqueIndexToSells1758394113356;
//# sourceMappingURL=1758394113356-AddUniqueIndexToSells.js.map