import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateProductsTable1758080000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1758080000000-CreateProductsTable.d.ts.map