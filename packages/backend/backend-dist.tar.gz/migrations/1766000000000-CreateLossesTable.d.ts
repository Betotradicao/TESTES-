import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateLossesTable1766000000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1766000000000-CreateLossesTable.d.ts.map