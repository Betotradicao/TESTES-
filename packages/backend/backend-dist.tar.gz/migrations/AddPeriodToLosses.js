"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddPeriodToLosses1735668900000 = void 0;
const typeorm_1 = require("typeorm");
class AddPeriodToLosses1735668900000 {
    async up(queryRunner) {
        await queryRunner.addColumn('losses', new typeorm_1.TableColumn({
            name: 'data_inicio_periodo',
            type: 'date',
            isNullable: true,
        }));
        await queryRunner.addColumn('losses', new typeorm_1.TableColumn({
            name: 'data_fim_periodo',
            type: 'date',
            isNullable: true,
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropColumn('losses', 'data_fim_periodo');
        await queryRunner.dropColumn('losses', 'data_inicio_periodo');
    }
}
exports.AddPeriodToLosses1735668900000 = AddPeriodToLosses1735668900000;
//# sourceMappingURL=AddPeriodToLosses.js.map