import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateSellsTable1758090000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1758090000000-CreateSellsTable.d.ts.map