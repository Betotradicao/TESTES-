import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateBipsTable1758062371000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1758062371000-CreateBipsTable.d.ts.map