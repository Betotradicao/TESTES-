import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateEquipmentsTable1759493626143 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1759493626143-CreateEquipmentsTable.d.ts.map