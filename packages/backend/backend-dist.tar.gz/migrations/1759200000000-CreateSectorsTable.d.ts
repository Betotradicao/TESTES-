import { MigrationInterface, QueryRunner } from "typeorm";
export declare class CreateSectorsTable1759200000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
//# sourceMappingURL=1759200000000-CreateSectorsTable.d.ts.map