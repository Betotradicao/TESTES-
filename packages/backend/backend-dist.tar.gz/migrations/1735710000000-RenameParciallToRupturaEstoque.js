"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RenameParciallToRupturaEstoque1735710000000 = void 0;
class RenameParciallToRupturaEstoque1735710000000 {
    async up(queryRunner) {
        // Atualizar registros existentes de 'parcial' para 'ruptura_estoque'
        await queryRunner.query(`
      UPDATE rupture_survey_items
      SET status_verificacao = 'ruptura_estoque'
      WHERE status_verificacao = 'parcial'
    `);
        // Alterar o tipo ENUM para incluir novo valor e remover antigo
        await queryRunner.query(`
      ALTER TYPE rupture_survey_items_status_verificacao_enum
      RENAME TO rupture_survey_items_status_verificacao_enum_old
    `);
        await queryRunner.query(`
      CREATE TYPE rupture_survey_items_status_verificacao_enum AS ENUM(
        'pendente',
        'encontrado',
        'nao_encontrado',
        'ruptura_estoque'
      )
    `);
        await queryRunner.query(`
      ALTER TABLE rupture_survey_items
      ALTER COLUMN status_verificacao TYPE rupture_survey_items_status_verificacao_enum
      USING status_verificacao::text::rupture_survey_items_status_verificacao_enum
    `);
        await queryRunner.query(`
      DROP TYPE rupture_survey_items_status_verificacao_enum_old
    `);
    }
    async down(queryRunner) {
        // Reverter: ruptura_estoque -> parcial
        await queryRunner.query(`
      UPDATE rupture_survey_items
      SET status_verificacao = 'parcial'
      WHERE status_verificacao = 'ruptura_estoque'
    `);
        await queryRunner.query(`
      ALTER TYPE rupture_survey_items_status_verificacao_enum
      RENAME TO rupture_survey_items_status_verificacao_enum_old
    `);
        await queryRunner.query(`
      CREATE TYPE rupture_survey_items_status_verificacao_enum AS ENUM(
        'pendente',
        'encontrado',
        'nao_encontrado',
        'parcial'
      )
    `);
        await queryRunner.query(`
      ALTER TABLE rupture_survey_items
      ALTER COLUMN status_verificacao TYPE rupture_survey_items_status_verificacao_enum
      USING status_verificacao::text::rupture_survey_items_status_verificacao_enum
    `);
        await queryRunner.query(`
      DROP TYPE rupture_survey_items_status_verificacao_enum_old
    `);
    }
}
exports.RenameParciallToRupturaEstoque1735710000000 = RenameParciallToRupturaEstoque1735710000000;
//# sourceMappingURL=1735710000000-RenameParciallToRupturaEstoque.js.map