export declare class Sector {
    id: number;
    name: string;
    color_hash: string;
    active: boolean;
    created_at: Date;
    updated_at: Date;
}
//# sourceMappingURL=Sector.d.ts.map