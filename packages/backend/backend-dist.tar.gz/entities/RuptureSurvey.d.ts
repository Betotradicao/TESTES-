import { RuptureSurveyItem } from './RuptureSurveyItem';
import { User } from './User';
export declare class RuptureSurvey {
    id: number;
    nome_pesquisa: string;
    data_criacao: Date;
    data_inicio_coleta: Date | null;
    data_fim_coleta: Date | null;
    status: 'rascunho' | 'em_andamento' | 'concluida' | 'cancelada';
    total_itens: number;
    itens_verificados: number;
    itens_encontrados: number;
    itens_nao_encontrados: number;
    user_id: string | null;
    user: User;
    observacoes: string | null;
    items: RuptureSurveyItem[];
    updated_at: Date;
    get taxa_ruptura(): number;
    get progresso_percentual(): number;
}
//# sourceMappingURL=RuptureSurvey.d.ts.map