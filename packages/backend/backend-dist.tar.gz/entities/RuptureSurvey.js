"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuptureSurvey = void 0;
const typeorm_1 = require("typeorm");
const RuptureSurveyItem_1 = require("./RuptureSurveyItem");
const User_1 = require("./User");
let RuptureSurvey = class RuptureSurvey {
    id;
    nome_pesquisa;
    data_criacao;
    data_inicio_coleta;
    data_fim_coleta;
    status;
    total_itens;
    itens_verificados;
    itens_encontrados;
    itens_nao_encontrados;
    user_id;
    user;
    observacoes;
    items;
    updated_at;
    // Campos calculados (não salvos no banco)
    get taxa_ruptura() {
        if (this.itens_verificados === 0)
            return 0;
        return (this.itens_nao_encontrados / this.itens_verificados) * 100;
    }
    get progresso_percentual() {
        if (this.total_itens === 0)
            return 0;
        return (this.itens_verificados / this.total_itens) * 100;
    }
};
exports.RuptureSurvey = RuptureSurvey;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], RuptureSurvey.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], RuptureSurvey.prototype, "nome_pesquisa", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], RuptureSurvey.prototype, "data_criacao", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Object)
], RuptureSurvey.prototype, "data_inicio_coleta", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Object)
], RuptureSurvey.prototype, "data_fim_coleta", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['rascunho', 'em_andamento', 'concluida', 'cancelada'],
        default: 'rascunho'
    }),
    __metadata("design:type", String)
], RuptureSurvey.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], RuptureSurvey.prototype, "total_itens", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], RuptureSurvey.prototype, "itens_verificados", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], RuptureSurvey.prototype, "itens_encontrados", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], RuptureSurvey.prototype, "itens_nao_encontrados", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'uuid', nullable: true }),
    __metadata("design:type", Object)
], RuptureSurvey.prototype, "user_id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => User_1.User, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'user_id' }),
    __metadata("design:type", User_1.User)
], RuptureSurvey.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", Object)
], RuptureSurvey.prototype, "observacoes", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => RuptureSurveyItem_1.RuptureSurveyItem, item => item.survey),
    __metadata("design:type", Array)
], RuptureSurvey.prototype, "items", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)(),
    __metadata("design:type", Date)
], RuptureSurvey.prototype, "updated_at", void 0);
exports.RuptureSurvey = RuptureSurvey = __decorate([
    (0, typeorm_1.Entity)('rupture_surveys')
], RuptureSurvey);
//# sourceMappingURL=RuptureSurvey.js.map