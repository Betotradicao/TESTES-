"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabelAudit = void 0;
const typeorm_1 = require("typeorm");
const LabelAuditItem_1 = require("./LabelAuditItem");
let LabelAudit = class LabelAudit {
    id;
    titulo;
    data_referencia;
    observacoes;
    status;
    items;
    created_at;
    updated_at;
    // Campos calculados (serão populados via query)
    total_itens;
    itens_pendentes;
    itens_corretos;
    itens_divergentes;
    percentual_conformidade;
};
exports.LabelAudit = LabelAudit;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], LabelAudit.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], LabelAudit.prototype, "titulo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'date' }),
    __metadata("design:type", Date)
], LabelAudit.prototype, "data_referencia", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", Object)
], LabelAudit.prototype, "observacoes", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['em_andamento', 'concluida', 'cancelada'],
        default: 'em_andamento'
    }),
    __metadata("design:type", String)
], LabelAudit.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => LabelAuditItem_1.LabelAuditItem, item => item.audit),
    __metadata("design:type", Array)
], LabelAudit.prototype, "items", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], LabelAudit.prototype, "created_at", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)(),
    __metadata("design:type", Date)
], LabelAudit.prototype, "updated_at", void 0);
exports.LabelAudit = LabelAudit = __decorate([
    (0, typeorm_1.Entity)('label_audits')
], LabelAudit);
//# sourceMappingURL=LabelAudit.js.map