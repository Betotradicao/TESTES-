export declare class Configuration {
    id: string;
    key: string;
    value: string | null;
    encrypted: boolean;
    created_at: Date;
    updated_at: Date;
}
//# sourceMappingURL=Configuration.d.ts.map