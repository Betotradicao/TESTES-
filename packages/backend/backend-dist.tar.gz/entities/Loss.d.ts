import { Company } from './Company';
export declare class Loss {
    id: number;
    companyId: string;
    company: Company;
    codigoBarras: string;
    descricaoReduzida: string;
    quantidadeAjuste: number;
    custoReposicao: number;
    descricaoAjusteCompleta: string;
    secao: string;
    secaoNome?: string;
    dataImportacao: Date;
    dataInicioPeriodo?: Date;
    dataFimPeriodo?: Date;
    nomeLote: string;
    createdAt: Date;
    updatedAt: Date;
}
//# sourceMappingURL=Loss.d.ts.map