"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuptureSurveyItem = void 0;
const typeorm_1 = require("typeorm");
const RuptureSurvey_1 = require("./RuptureSurvey");
let RuptureSurveyItem = class RuptureSurveyItem {
    id;
    survey_id;
    survey;
    codigo_barras;
    erp_product_id;
    descricao;
    curva;
    estoque_atual;
    cobertura_dias;
    grupo;
    secao;
    subgrupo;
    fornecedor;
    margem_lucro;
    qtd_embalagem;
    valor_venda;
    custo_com_imposto;
    venda_media_dia;
    tem_pedido;
    status_verificacao;
    data_verificacao;
    verificado_por;
    observacao_item;
    created_at;
    // Campos calculados
    get perda_venda_dia() {
        if (!this.venda_media_dia || !this.valor_venda)
            return 0;
        // Considerar tanto 'nao_encontrado' quanto 'ruptura_estoque' como perda
        if (this.status_verificacao !== 'nao_encontrado' && this.status_verificacao !== 'ruptura_estoque')
            return 0;
        return this.venda_media_dia * this.valor_venda;
    }
    get perda_lucro_dia() {
        if (!this.venda_media_dia || !this.valor_venda || !this.margem_lucro)
            return 0;
        // Considerar tanto 'nao_encontrado' quanto 'ruptura_estoque' como perda
        if (this.status_verificacao !== 'nao_encontrado' && this.status_verificacao !== 'ruptura_estoque')
            return 0;
        return this.venda_media_dia * this.valor_venda * (this.margem_lucro / 100);
    }
    get criticidade() {
        if (!this.venda_media_dia || !this.margem_lucro)
            return 0;
        const fatorCurva = this.curva === 'A' ? 3 : this.curva === 'B' ? 2 : 1;
        return fatorCurva * this.venda_media_dia * this.margem_lucro;
    }
};
exports.RuptureSurveyItem = RuptureSurveyItem;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], RuptureSurveyItem.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], RuptureSurveyItem.prototype, "survey_id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => RuptureSurvey_1.RuptureSurvey, survey => survey.items, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'survey_id' }),
    __metadata("design:type", RuptureSurvey_1.RuptureSurvey)
], RuptureSurveyItem.prototype, "survey", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "codigo_barras", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "erp_product_id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], RuptureSurveyItem.prototype, "descricao", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 10, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "curva", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 3, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "estoque_atual", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "cobertura_dias", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "grupo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "secao", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "subgrupo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "fornecedor", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 5, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "margem_lucro", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "qtd_embalagem", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "valor_venda", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "custo_com_imposto", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 4, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "venda_media_dia", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 3, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "tem_pedido", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['pendente', 'encontrado', 'nao_encontrado', 'ruptura_estoque'],
        default: 'pendente'
    }),
    __metadata("design:type", String)
], RuptureSurveyItem.prototype, "status_verificacao", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "data_verificacao", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "verificado_por", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", Object)
], RuptureSurveyItem.prototype, "observacao_item", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], RuptureSurveyItem.prototype, "created_at", void 0);
exports.RuptureSurveyItem = RuptureSurveyItem = __decorate([
    (0, typeorm_1.Entity)('rupture_survey_items')
], RuptureSurveyItem);
//# sourceMappingURL=RuptureSurveyItem.js.map