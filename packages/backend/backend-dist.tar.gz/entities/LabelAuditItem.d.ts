import { LabelAudit } from './LabelAudit';
export declare class LabelAuditItem {
    id: number;
    audit_id: number;
    audit: LabelAudit;
    codigo_barras: string | null;
    descricao: string;
    etiqueta: string | null;
    secao: string | null;
    valor_venda: number | null;
    valor_oferta: number | null;
    margem_pratica: string | null;
    status_verificacao: 'pendente' | 'preco_correto' | 'preco_divergente';
    data_verificacao: Date | null;
    verificado_por: string | null;
    observacao_item: string | null;
    created_at: Date;
}
//# sourceMappingURL=LabelAuditItem.d.ts.map