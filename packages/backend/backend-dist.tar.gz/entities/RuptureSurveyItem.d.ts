import { RuptureSurvey } from './RuptureSurvey';
export declare class RuptureSurveyItem {
    id: number;
    survey_id: number;
    survey: RuptureSurvey;
    codigo_barras: string | null;
    erp_product_id: string | null;
    descricao: string;
    curva: string | null;
    estoque_atual: number | null;
    cobertura_dias: number | null;
    grupo: string | null;
    secao: string | null;
    subgrupo: string | null;
    fornecedor: string | null;
    margem_lucro: number | null;
    qtd_embalagem: number | null;
    valor_venda: number | null;
    custo_com_imposto: number | null;
    venda_media_dia: number | null;
    tem_pedido: string | null;
    status_verificacao: 'pendente' | 'encontrado' | 'nao_encontrado' | 'ruptura_estoque';
    data_verificacao: Date | null;
    verificado_por: string | null;
    observacao_item: string | null;
    created_at: Date;
    get perda_venda_dia(): number;
    get perda_lucro_dia(): number;
    get criticidade(): number;
}
//# sourceMappingURL=RuptureSurveyItem.d.ts.map