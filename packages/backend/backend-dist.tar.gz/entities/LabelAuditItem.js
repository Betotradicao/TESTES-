"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabelAuditItem = void 0;
const typeorm_1 = require("typeorm");
const LabelAudit_1 = require("./LabelAudit");
let LabelAuditItem = class LabelAuditItem {
    id;
    audit_id;
    audit;
    codigo_barras;
    descricao;
    etiqueta;
    secao;
    valor_venda;
    valor_oferta;
    margem_pratica;
    status_verificacao;
    data_verificacao;
    verificado_por;
    observacao_item;
    created_at;
};
exports.LabelAuditItem = LabelAuditItem;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], LabelAuditItem.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], LabelAuditItem.prototype, "audit_id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => LabelAudit_1.LabelAudit, audit => audit.items, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'audit_id' }),
    __metadata("design:type", LabelAudit_1.LabelAudit)
], LabelAuditItem.prototype, "audit", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true }),
    __metadata("design:type", Object)
], LabelAuditItem.prototype, "codigo_barras", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], LabelAuditItem.prototype, "descricao", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 10, nullable: true }),
    __metadata("design:type", Object)
], LabelAuditItem.prototype, "etiqueta", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", Object)
], LabelAuditItem.prototype, "secao", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], LabelAuditItem.prototype, "valor_venda", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, nullable: true }),
    __metadata("design:type", Object)
], LabelAuditItem.prototype, "valor_oferta", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20, nullable: true }),
    __metadata("design:type", Object)
], LabelAuditItem.prototype, "margem_pratica", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['pendente', 'preco_correto', 'preco_divergente'],
        default: 'pendente'
    }),
    __metadata("design:type", String)
], LabelAuditItem.prototype, "status_verificacao", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true }),
    __metadata("design:type", Object)
], LabelAuditItem.prototype, "data_verificacao", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", Object)
], LabelAuditItem.prototype, "verificado_por", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", Object)
], LabelAuditItem.prototype, "observacao_item", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], LabelAuditItem.prototype, "created_at", void 0);
exports.LabelAuditItem = LabelAuditItem = __decorate([
    (0, typeorm_1.Entity)('label_audit_items')
], LabelAuditItem);
//# sourceMappingURL=LabelAuditItem.js.map