import { Company } from './Company';
export declare class LossReasonConfig {
    id: number;
    companyId?: string;
    company?: Company;
    motivo: string;
    ignorarCalculo: boolean;
    createdAt: Date;
    updatedAt: Date;
}
//# sourceMappingURL=LossReasonConfig.d.ts.map