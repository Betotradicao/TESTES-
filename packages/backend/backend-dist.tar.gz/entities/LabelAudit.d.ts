import { LabelAuditItem } from './LabelAuditItem';
export declare class LabelAudit {
    id: number;
    titulo: string;
    data_referencia: Date;
    observacoes: string | null;
    status: 'em_andamento' | 'concluida' | 'cancelada';
    items: LabelAuditItem[];
    created_at: Date;
    updated_at: Date;
    total_itens?: number;
    itens_pendentes?: number;
    itens_corretos?: number;
    itens_divergentes?: number;
    percentual_conformidade?: number;
}
//# sourceMappingURL=LabelAudit.d.ts.map