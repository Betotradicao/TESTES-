import { Sector } from './Sector';
export declare class Equipment {
    id: number;
    color_hash: string;
    scanner_machine_id: string;
    machine_id: string;
    port_number?: string;
    description: string;
    sector_id: number;
    sector: Sector;
    active: boolean;
    created_at: Date;
    updated_at: Date;
}
//# sourceMappingURL=Equipment.d.ts.map