import { Company } from './Company';
export declare enum UserRole {
    MASTER = "master",
    ADMIN = "admin",
    USER = "user"
}
export declare class User {
    id: string;
    name?: string;
    username?: string;
    email: string;
    password: string;
    role: UserRole;
    isMaster: boolean;
    companyId: string;
    company: Company;
    resetPasswordToken: string | null;
    resetPasswordExpires: Date | null;
    created_at: Date;
    updated_at: Date;
    hashPassword(): Promise<void>;
    validatePassword(password: string): Promise<boolean>;
}
//# sourceMappingURL=User.d.ts.map