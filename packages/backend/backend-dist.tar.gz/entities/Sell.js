"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Sell = void 0;
const typeorm_1 = require("typeorm");
const Product_1 = require("./Product");
const Bip_1 = require("./Bip");
let Sell = class Sell {
    id;
    activatedProductId;
    productId;
    productDescription;
    sellDate;
    sellValueCents;
    productWeight;
    bipId;
    numCupomFiscal;
    pointOfSaleCode;
    discountCents;
    status;
    createdAt;
    updatedAt;
    // Relations
    activatedProduct;
    bip;
    // Virtual properties for API response
    get sellValue() {
        return this.sellValueCents / 100;
    }
    get discountValue() {
        return this.discountCents / 100;
    }
    get finalValue() {
        return (this.sellValueCents - this.discountCents) / 100;
    }
    get statusDescription() {
        switch (this.status) {
            case 'verified':
                return 'Venda verificada - bipagem encontrada';
            case 'not_verified':
                return 'Venda não verificada - possível furto';
            case 'cancelled':
                return 'Venda cancelada';
            default:
                return 'Venda não verificada - possível furto';
        }
    }
};
exports.Sell = Sell;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Sell.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'activated_product_id' }),
    __metadata("design:type", Number)
], Sell.prototype, "activatedProductId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'product_id', length: 20 }),
    __metadata("design:type", String)
], Sell.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'product_description', type: 'text' }),
    __metadata("design:type", String)
], Sell.prototype, "productDescription", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sell_date', type: 'timestamp' }),
    __metadata("design:type", Date)
], Sell.prototype, "sellDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sell_value_cents', type: 'integer' }),
    __metadata("design:type", Number)
], Sell.prototype, "sellValueCents", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'product_weight', type: 'decimal', precision: 12, scale: 3 }),
    __metadata("design:type", Number)
], Sell.prototype, "productWeight", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bip_id', nullable: true }),
    __metadata("design:type", Object)
], Sell.prototype, "bipId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'num_cupom_fiscal', type: 'integer', nullable: true }),
    __metadata("design:type", Object)
], Sell.prototype, "numCupomFiscal", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'point_of_sale_code', type: 'integer', nullable: true }),
    __metadata("design:type", Object)
], Sell.prototype, "pointOfSaleCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'discount_cents', type: 'integer', default: 0 }),
    __metadata("design:type", Number)
], Sell.prototype, "discountCents", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 20 }),
    __metadata("design:type", String)
], Sell.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], Sell.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], Sell.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => Product_1.Product),
    (0, typeorm_1.JoinColumn)({ name: 'activated_product_id' }),
    __metadata("design:type", Product_1.Product)
], Sell.prototype, "activatedProduct", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => Bip_1.Bip, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'bip_id' }),
    __metadata("design:type", Object)
], Sell.prototype, "bip", void 0);
exports.Sell = Sell = __decorate([
    (0, typeorm_1.Entity)('sells')
], Sell);
//# sourceMappingURL=Sell.js.map