import { Equipment } from './Equipment';
import { Employee } from './Employee';
export declare enum BipStatus {
    PENDING = "pending",
    VERIFIED = "verified",
    CANCELLED = "cancelled"
}
export declare enum MotivoCancelamento {
    PRODUTO_ABANDONADO = "produto_abandonado",
    FALTA_CANCELAMENTO = "falta_cancelamento",
    DEVOLUCAO_MERCADORIA = "devolucao_mercadoria",
    ERRO_OPERADOR = "erro_operador",
    ERRO_BALCONISTA = "erro_balconista",
    FURTO = "furto"
}
export declare class Bip {
    id: number;
    ean: string;
    event_date: Date;
    bip_price_cents: number;
    product_id: string;
    product_description: string | null;
    product_full_price_cents_kg: number | null;
    product_discount_price_cents_kg: number | null;
    bip_weight: number | null;
    tax_cupon: string | null;
    status: BipStatus;
    notified_at: Date | null;
    equipment_id: number;
    equipment: Equipment;
    employee_id: string | null;
    employee: Employee | null;
    motivo_cancelamento: MotivoCancelamento | null;
    employee_responsavel_id: string | null;
    employee_responsavel: Employee | null;
    video_url: string | null;
    image_url: string | null;
}
//# sourceMappingURL=Bip.d.ts.map