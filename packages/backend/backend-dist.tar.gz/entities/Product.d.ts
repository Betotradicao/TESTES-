import { ProductActivationHistory } from './ProductActivationHistory';
export declare class Product {
    id: number;
    erp_product_id: string;
    description: string;
    short_description: string | null;
    ean: string | null;
    weighable: boolean;
    section_code: number | null;
    section_name: string | null;
    group_code: number | null;
    group_name: string | null;
    subgroup_code: number | null;
    subgroup_name: string | null;
    supplier_code: number | null;
    supplier_name: string | null;
    active: boolean;
    foto_referencia?: string;
    coloracao?: string;
    formato?: string;
    gordura_visivel?: string;
    presenca_osso?: boolean;
    peso_min_kg?: number;
    peso_max_kg?: number;
    posicao_balcao?: {
        setor?: string;
        balcao?: number;
        posicao?: string;
    };
    created_at: Date;
    updated_at: Date;
    activationHistory: ProductActivationHistory[];
}
//# sourceMappingURL=Product.d.ts.map