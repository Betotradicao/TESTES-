"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = require("../config/database");
async function runMigrations() {
    try {
        console.log('🔌 Conectando ao banco de dados...');
        await database_1.AppDataSource.initialize();
        console.log('🏃 Rodando migrações pendentes...');
        const migrations = await database_1.AppDataSource.runMigrations();
        if (migrations.length === 0) {
            console.log('✅ Nenhuma migração pendente!');
        }
        else {
            console.log(`✅ ${migrations.length} migrações executadas com sucesso:`);
            migrations.forEach(migration => {
                console.log(`   - ${migration.name}`);
            });
        }
        await database_1.AppDataSource.destroy();
        process.exit(0);
    }
    catch (error) {
        console.error('❌ Erro ao executar migrações:', error);
        process.exit(1);
    }
}
runMigrations();
//# sourceMappingURL=run-migration.js.map