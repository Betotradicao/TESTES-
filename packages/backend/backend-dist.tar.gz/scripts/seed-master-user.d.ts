/**
 * Script para criar usuário MASTER (desenvolvedor)
 *
 * Usuário: Roberto
 * Senha: Beto3107@@##
 * Role: MASTER
 *
 * Este usuário é criado automaticamente na inicialização
 * e tem acesso total ao sistema, incluindo Configurações de Rede
 */
declare function seedMasterUser(): Promise<void>;
export { seedMasterUser };
//# sourceMappingURL=seed-master-user.d.ts.map