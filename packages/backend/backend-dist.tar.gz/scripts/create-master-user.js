"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = require("../config/database");
const User_1 = require("../entities/User");
const bcrypt_1 = __importDefault(require("bcrypt"));
/**
 * Script para criar o usuário master padrão do sistema
 * Este usuário é criado automaticamente em toda instalação nova
 *
 * Usuário: Roberto
 * Senha: Beto3107@@##
 * isMaster: true
 */
async function createMasterUser() {
    try {
        console.log('🔧 Iniciando criação do usuário master...');
        if (!database_1.AppDataSource.isInitialized) {
            await database_1.AppDataSource.initialize();
        }
        const userRepository = database_1.AppDataSource.getRepository(User_1.User);
        // Verificar se já existe usuário master
        const existingMaster = await userRepository.findOne({
            where: { username: 'Roberto' }
        });
        if (existingMaster) {
            console.log('✅ Usuário master Roberto já existe');
            // Atualizar senha e garantir que é master
            const hashedPassword = await bcrypt_1.default.hash('Beto3107@@##', 10);
            existingMaster.password = hashedPassword;
            existingMaster.isMaster = true;
            existingMaster.role = User_1.UserRole.ADMIN;
            await userRepository.save(existingMaster);
            console.log('✅ Senha e permissões do usuário master atualizadas');
            process.exit(0);
            return;
        }
        // Criar novo usuário master
        const hashedPassword = await bcrypt_1.default.hash('Beto3107@@##', 10);
        const masterUser = userRepository.create({
            name: 'ROBERTO BASTOS RUIVO',
            username: 'Roberto',
            email: 'betotradicao76@gmail.com',
            password: hashedPassword,
            role: User_1.UserRole.ADMIN,
            isMaster: true,
        });
        await userRepository.save(masterUser);
        console.log('✅ Usuário master criado com sucesso!');
        console.log('   Username: Roberto');
        console.log('   Senha: Beto3107@@##');
        console.log('   Email: betotradicao76@gmail.com');
        console.log('   isMaster: true');
        process.exit(0);
    }
    catch (error) {
        console.error('❌ Erro ao criar usuário master:', error);
        process.exit(1);
    }
}
// Executar se chamado diretamente
if (require.main === module) {
    createMasterUser();
}
exports.default = createMasterUser;
//# sourceMappingURL=create-master-user.js.map