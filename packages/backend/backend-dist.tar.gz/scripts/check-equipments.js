"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const database_1 = require("../config/database");
const Equipment_1 = require("../entities/Equipment");
async function checkEquipments() {
    try {
        await database_1.AppDataSource.initialize();
        const equipmentRepository = database_1.AppDataSource.getRepository(Equipment_1.Equipment);
        const all = await equipmentRepository.find();
        console.log('=== EQUIPAMENTOS NO BANCO ===');
        all.forEach(e => {
            console.log(`ID: ${e.id} | scanner_machine_id: ${e.scanner_machine_id} | machine_id: ${e.machine_id}`);
        });
        console.log(`Total: ${all.length}`);
        await database_1.AppDataSource.destroy();
    }
    catch (error) {
        console.error('Erro:', error);
        process.exit(1);
    }
}
checkEquipments();
//# sourceMappingURL=check-equipments.js.map