/**
 * Script para criar o usuário master padrão do sistema
 * Este usuário é criado automaticamente em toda instalação nova
 *
 * Usuário: Roberto
 * Senha: Beto3107@@##
 * isMaster: true
 */
declare function createMasterUser(): Promise<void>;
export default createMasterUser;
//# sourceMappingURL=create-master-user.d.ts.map