import 'reflect-metadata';
//# sourceMappingURL=clear-equipments.d.ts.map