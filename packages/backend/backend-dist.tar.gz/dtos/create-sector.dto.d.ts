export declare class CreateSectorDto {
    name: string;
    color_hash?: string;
}
export declare function validateCreateSector(data: any): {
    valid: boolean;
    errors?: string[];
};
//# sourceMappingURL=create-sector.dto.d.ts.map