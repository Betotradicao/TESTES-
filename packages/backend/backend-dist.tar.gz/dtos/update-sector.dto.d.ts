export declare class UpdateSectorDto {
    name?: string;
    color_hash?: string;
}
export declare function validateUpdateSector(data: any): {
    valid: boolean;
    errors?: string[];
};
//# sourceMappingURL=update-sector.dto.d.ts.map