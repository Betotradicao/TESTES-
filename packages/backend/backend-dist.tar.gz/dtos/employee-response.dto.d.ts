export declare class EmployeeResponseDto {
    id: string;
    name: string;
    avatar: string | null;
    sector_id: number;
    sector?: {
        id: number;
        name: string;
        color_hash: string;
    };
    function_description: string;
    username: string;
    first_access: boolean;
    barcode: string;
    active: boolean;
    created_at: Date;
    updated_at: Date;
    constructor(employee: any);
}
//# sourceMappingURL=employee-response.dto.d.ts.map