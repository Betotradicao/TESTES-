import { RuptureSurvey } from '../entities/RuptureSurvey';
import { RuptureSurveyItem } from '../entities/RuptureSurveyItem';
export declare class RupturePDFService {
    /**
     * Converte valor para número (trata strings e Decimal do TypeORM)
     */
    private static toNumber;
    /**
     * Gera PDF da auditoria de ruptura agrupado por tipo
     * Retorna o caminho do arquivo PDF gerado
     */
    static generateRupturePDF(survey: RuptureSurvey, items: RuptureSurveyItem[]): Promise<string>;
    /**
     * Desenha cabeçalho da tabela com fundo laranja
     */
    private static drawTableHeader;
    /**
     * Desenha linha da tabela com zebra (alternando cores)
     */
    private static drawTableRow;
    /**
     * Trunca texto longo
     */
    private static truncate;
    /**
     * Remove arquivo PDF temporário
     */
    static deletePDF(filePath: string): Promise<void>;
}
//# sourceMappingURL=rupture-pdf.service.d.ts.map