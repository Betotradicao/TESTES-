import { Loss } from '../entities/Loss';
export declare class LossService {
    /**
     * Processa arquivo CSV e importa perdas
     */
    static importFromFile(filePath: string, nomeLote: string, companyId: string, dataInicioCustom?: string, dataFimCustom?: string): Promise<{
        total: number;
        perdas: number;
        entradas: number;
    }>;
    /**
     * Buscar todos os lotes
     */
    static getAllLotes(companyId: string): Promise<any[]>;
    /**
     * Buscar perdas por lote
     */
    static getByLote(nomeLote: string, companyId: string): Promise<Loss[]>;
    /**
     * Buscar perdas agregadas por seção
     */
    static getAggregatedBySection(nomeLote: string, companyId: string): Promise<any[]>;
    /**
     * Deletar lote
     */
    static deleteLote(nomeLote: string, companyId: string): Promise<void>;
    /**
     * Buscar resultados agregados com filtros
     */
    static getAgregatedResults(filters: {
        data_inicio: string;
        data_fim: string;
        motivo?: string;
        produto?: string;
        tipo?: string;
        companyId: string;
        page?: number;
        limit?: number;
    }): Promise<any>;
    /**
     * Buscar seções únicas para filtro
     */
    static getUniqueSecoes(companyId: string): Promise<any[]>;
    /**
     * Buscar produtos únicos para filtro
     */
    static getUniqueProdutos(companyId: string): Promise<string[]>;
    /**
     * Buscar motivos únicos
     */
    static getUniqueMotivos(companyId: string): Promise<string[]>;
    /**
     * Alternar motivo ignorado
     */
    static toggleMotivoIgnorado(motivo: string, companyId: string): Promise<any>;
    /**
     * Listar motivos ignorados
     */
    static getMotivosIgnorados(companyId: string): Promise<any[]>;
}
//# sourceMappingURL=loss.service.d.ts.map