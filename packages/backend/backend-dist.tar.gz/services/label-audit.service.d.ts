import { LabelAudit } from '../entities/LabelAudit';
import { LabelAuditItem } from '../entities/LabelAuditItem';
export declare class LabelAuditService {
    /**
     * Processa arquivo CSV e cria auditoria de etiquetas
     */
    static createAuditFromFile(filePath: string, titulo: string, dataReferencia: Date, userId: string): Promise<LabelAudit>;
    /**
     * Helper para converter preço brasileiro (45,99) para decimal
     */
    private static parsePrice;
    /**
     * Listar todas as auditorias com estatísticas
     */
    static getAllAudits(): Promise<LabelAudit[]>;
    /**
     * Buscar auditoria por ID com itens
     */
    static getAuditById(auditId: number): Promise<LabelAudit | null>;
    /**
     * Buscar itens pendentes para verificação (ordenados por seção)
     */
    static getPendingItems(auditId: number): Promise<LabelAuditItem[]>;
    /**
     * Verificar item (marcar como correto ou divergente)
     */
    static verifyItem(itemId: number, statusVerificacao: 'preco_correto' | 'preco_divergente', verificadoPor: string, observacao?: string): Promise<LabelAuditItem>;
    /**
     * Gerar relatório PDF com itens divergentes
     */
    static generateDivergentReport(auditId: number): Promise<Buffer>;
    /**
     * Enviar relatório via WhatsApp
     */
    static sendDivergentReportToWhatsApp(auditId: number): Promise<void>;
    /**
     * Deletar auditoria
     */
    static deleteAudit(auditId: number): Promise<void>;
}
//# sourceMappingURL=label-audit.service.d.ts.map