import { WebhookPayload, EanFormatResult } from '../types/webhook.types';
export declare class EanFormatterService {
    /**
     * Formata e valida EAN-13 extraindo informações do código
     * Replica exatamente a lógica do N8N
     */
    static formatEan(payload: WebhookPayload): EanFormatResult;
}
//# sourceMappingURL=ean-formatter.service.d.ts.map