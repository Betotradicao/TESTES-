interface CronHealthStatus {
    lastExecution: Date | null;
    isHealthy: boolean;
    minutesSinceLastRun: number | null;
}
/**
 * Monitora a saúde do CRON de verificação
 * Se detectar que não está rodando, reexecuta automaticamente
 */
export declare class CronHealthMonitorService {
    private static lastExecutionTime;
    private static readonly MAX_MINUTES_WITHOUT_EXECUTION;
    /**
     * Atualiza o timestamp da última execução
     */
    static recordExecution(): void;
    /**
     * Verifica se o CRON está saudável (rodando regularmente)
     */
    static getHealthStatus(): CronHealthStatus;
    /**
     * Auto-recuperação: Se CRON não rodar há muito tempo, força execução
     */
    static autoRecovery(): Promise<void>;
    /**
     * Salva status no banco de dados para ser exibido no frontend
     */
    static saveStatusToDatabase(): Promise<void>;
}
export {};
//# sourceMappingURL=cron-health-monitor.service.d.ts.map