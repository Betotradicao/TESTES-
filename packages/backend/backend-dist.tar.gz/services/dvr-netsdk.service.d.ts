/**
 * Serviço DVR usando Intelbras NetSDK
 * Substitui a conexão TCP simples por uma integração completa via SDK
 */
import { PTZCommand } from '../lib/intelbras-netsdk';
import { Sale } from './sales.service';
export interface DVRNetSDKConfig {
    enabled: boolean;
    dvrIp: string;
    dvrPort: number;
    username: string;
    password: string;
    channelCount: number;
    snapshotPath: string;
}
export declare class DVRNetSDKService {
    private static sdk;
    private static loginHandle;
    private static config;
    private static reconnectTimer;
    /**
     * Inicializa o serviço NetSDK
     */
    static initialize(): Promise<void>;
    /**
     * Carrega configurações do banco de dados
     */
    private static loadConfig;
    /**
     * Conecta ao DVR via NetSDK
     */
    private static connect;
    /**
     * Agenda reconexão automática
     */
    private static scheduleReconnect;
    /**
     * Captura snapshot de um canal
     */
    static captureSnapshot(channel?: number): Promise<string | null>;
    /**
     * Controla PTZ da câmera
     */
    static controlPTZ(channel: number, command: PTZCommand, speed?: number): Promise<boolean>;
    /**
     * Move câmera PTZ para cima
     */
    static movePTZUp(channel: number, speed?: number): Promise<boolean>;
    /**
     * Move câmera PTZ para baixo
     */
    static movePTZDown(channel: number, speed?: number): Promise<boolean>;
    /**
     * Move câmera PTZ para esquerda
     */
    static movePTZLeft(channel: number, speed?: number): Promise<boolean>;
    /**
     * Move câmera PTZ para direita
     */
    static movePTZRight(channel: number, speed?: number): Promise<boolean>;
    /**
     * Zoom in da câmera
     */
    static ptzZoomIn(channel: number, speed?: number): Promise<boolean>;
    /**
     * Zoom out da câmera
     */
    static ptzZoomOut(channel: number, speed?: number): Promise<boolean>;
    /**
     * Define preset PTZ
     */
    static setPTZPreset(channel: number, presetNumber: number): Promise<boolean>;
    /**
     * Vai para preset PTZ
     */
    static gotoPTZPreset(channel: number, presetNumber: number): Promise<boolean>;
    /**
     * Testa a conexão com o DVR
     */
    static testConnection(): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Obtém status da conexão
     */
    static getConnectionStatus(): {
        connected: boolean;
        loginHandle: number;
        config: DVRNetSDKConfig | null;
    };
    /**
     * Desconecta do DVR e limpa recursos
     */
    static disconnect(): void;
    /**
     * Processa uma venda (mantido para compatibilidade com o sistema atual)
     * Nota: O NetSDK não envia texto diretamente. Esta função poderia ser
     * adaptada para gravar um log ou capturar snapshot da venda.
     */
    static processSale(sale: Sale): Promise<boolean>;
}
export default DVRNetSDKService;
//# sourceMappingURL=dvr-netsdk.service.d.ts.map