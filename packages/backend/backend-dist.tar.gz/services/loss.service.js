"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LossService = void 0;
const database_1 = require("../config/database");
const Loss_1 = require("../entities/Loss");
const fs = __importStar(require("fs"));
const papaparse_1 = __importDefault(require("papaparse"));
// Mapeamento de número da seção para nome
const SECAO_MAP = {
    '1': 'Açougue',
    '2': 'Padaria',
    '3': 'Bebidas',
    '4': 'Bebidas',
    '5': 'Mercearia',
    '6': 'Limpeza',
    '7': 'Higiene/Perfumaria',
    '8': 'Frios/Laticínios',
    '9': 'Limpeza',
    '10': 'Bazar',
    '11': 'Mercearia',
    '12': 'FLV (Frutas, Legumes e Verduras)',
    '13': 'Congelados',
    '14': 'Têxtil',
    '15': 'Outros',
    '16': 'Mercearia',
};
class LossService {
    /**
     * Processa arquivo CSV e importa perdas
     */
    static async importFromFile(filePath, nomeLote, companyId, dataInicioCustom, dataFimCustom) {
        try {
            console.log(`📂 Processando arquivo de perdas: ${filePath}`);
            // Ler arquivo CSV - tentar UTF-8 primeiro, depois Latin1
            let fileContent;
            try {
                fileContent = fs.readFileSync(filePath, 'utf-8');
                // Se tiver caracteres de replacement (�), tentar Latin1
                if (fileContent.includes('�')) {
                    console.log('⚠️ Detectado encoding incorreto, tentando Latin1...');
                    const buffer = fs.readFileSync(filePath);
                    fileContent = buffer.toString('latin1');
                }
            }
            catch (err) {
                // Fallback para Latin1
                const buffer = fs.readFileSync(filePath);
                fileContent = buffer.toString('latin1');
            }
            // Remover BOM se existir
            if (fileContent.charCodeAt(0) === 0xFEFF) {
                fileContent = fileContent.slice(1);
            }
            // Dividir em linhas para encontrar o header real
            const lines = fileContent.split('\n');
            // Encontrar a linha que contém "Código de Barras" (header real)
            let headerLineIndex = lines.findIndex(line => line.includes('C�digo de Barras') || line.includes('Código de Barras'));
            // Se não encontrou, tentar pular as primeiras 4 linhas (padrão do CSV)
            if (headerLineIndex === -1) {
                headerLineIndex = 4;
            }
            // Reconstruir CSV a partir do header real
            const cleanedContent = lines.slice(headerLineIndex).join('\n');
            // Parsear CSV usando parse síncrono
            const parseResult = papaparse_1.default.parse(cleanedContent, {
                header: true,
                skipEmptyLines: true,
                delimiter: ';', // CSV usa ponto-e-vírgula
            });
            if (parseResult.errors && parseResult.errors.length > 0) {
                console.error('❌ Erros ao parsear CSV:', parseResult.errors);
                throw new Error('Erro ao processar arquivo CSV');
            }
            const rows = parseResult.data || [];
            console.log(`📊 ${rows.length} linhas encontradas no CSV`);
            // Log dos headers para debug
            if (rows.length > 0) {
                console.log('🔍 Headers encontrados:', Object.keys(rows[0]));
            }
            // Filtrar linhas válidas
            const validRows = rows.filter(row => {
                const codigoBarras = row['C�digo de Barras'] || row['Código de Barras'];
                const descricao = row['Descri��o Reduzida'] || row['Descrição Reduzida'];
                // Aceitar linha se tiver código de barras OU descrição, e não for linha de cabeçalho
                return (codigoBarras || descricao) &&
                    !String(codigoBarras || '').includes('SUPERMERCADO') &&
                    !String(codigoBarras || '').includes('CEP') &&
                    !String(codigoBarras || '').includes('CNPJ') &&
                    !String(codigoBarras || '').includes('C�digo de Barras');
            });
            console.log(`✅ ${validRows.length} registros válidos encontrados`);
            // Importar registros
            const lossRepository = database_1.AppDataSource.getRepository(Loss_1.Loss);
            // Usar apenas data inicial para os registros reais (corrigir timezone UTC)
            const dataImportacao = dataInicioCustom ? new Date(dataInicioCustom + 'T12:00:00') : new Date();
            const dataInicioPeriodo = dataInicioCustom ? new Date(dataInicioCustom + 'T12:00:00') : new Date();
            const dataFimPeriodo = dataFimCustom ? new Date(dataFimCustom + 'T12:00:00') : dataInicioPeriodo;
            console.log(`📅 Data de importação: ${dataImportacao.toLocaleDateString('pt-BR')}`);
            console.log(`📅 Período: ${dataInicioPeriodo.toLocaleDateString('pt-BR')} até ${dataFimPeriodo.toLocaleDateString('pt-BR')}`);
            let perdas = 0;
            let entradas = 0;
            // Importar cada linha do CSV apenas UMA VEZ
            for (const row of validRows) {
                const quantidadeStr = (row['Quantidade Ajuste'] || '0').replace(',', '.');
                const quantidade = parseFloat(quantidadeStr);
                const custoStr = (row['Custo Reposi��o'] || row['Custo Reposição'] || '0').replace(',', '.');
                const custo = parseFloat(custoStr);
                const secao = (row['Se��o'] || row['Seção'] || '0').trim();
                // Contar perdas vs entradas
                if (quantidade < 0) {
                    perdas++;
                }
                else {
                    entradas++;
                }
                const loss = lossRepository.create({
                    companyId,
                    codigoBarras: row['C�digo de Barras'] || row['Código de Barras'] || '',
                    descricaoReduzida: row['Descri��o Reduzida'] || row['Descrição Reduzida'] || '',
                    quantidadeAjuste: quantidade,
                    custoReposicao: custo,
                    descricaoAjusteCompleta: row['Descri��o Ajuste Completa'] || row['Descrição Ajuste Completa'] || '',
                    secao: secao,
                    secaoNome: SECAO_MAP[secao] || 'Outros',
                    dataImportacao,
                    dataInicioPeriodo,
                    dataFimPeriodo,
                    nomeLote,
                });
                await lossRepository.save(loss);
            }
            console.log(`✅ Importação concluída: ${validRows.length} registros (${perdas} perdas, ${entradas} entradas)`);
            return {
                total: validRows.length,
                perdas,
                entradas,
            };
        }
        catch (error) {
            console.error('❌ Erro ao importar perdas:', error);
            throw error;
        }
    }
    /**
     * Buscar todos os lotes
     */
    static async getAllLotes(companyId) {
        const lossRepository = database_1.AppDataSource.getRepository(Loss_1.Loss);
        const result = await lossRepository
            .createQueryBuilder('loss')
            .select('loss.nome_lote', 'nomeLote')
            .addSelect('loss.data_importacao', 'dataImportacao')
            .addSelect('loss.data_inicio_periodo', 'dataInicioPeriodo')
            .addSelect('loss.data_fim_periodo', 'dataFimPeriodo')
            .addSelect('COUNT(*)', 'totalRegistros')
            .addSelect('SUM(CASE WHEN loss.quantidade_ajuste < 0 THEN 1 ELSE 0 END)', 'totalPerdas')
            .addSelect('SUM(CASE WHEN loss.quantidade_ajuste >= 0 THEN 1 ELSE 0 END)', 'totalEntradas')
            .addSelect('SUM(CASE WHEN loss.quantidade_ajuste < 0 THEN ABS(loss.quantidade_ajuste * loss.custo_reposicao) ELSE 0 END)', 'valorPerdas')
            .where('loss.company_id = :companyId', { companyId })
            .groupBy('loss.nome_lote')
            .addGroupBy('loss.data_importacao')
            .addGroupBy('loss.data_inicio_periodo')
            .addGroupBy('loss.data_fim_periodo')
            .orderBy('loss.data_importacao', 'DESC')
            .getRawMany();
        return result.map((r) => ({
            nomeLote: r.nomeLote,
            dataImportacao: r.dataImportacao,
            dataInicioPeriodo: r.dataInicioPeriodo,
            dataFimPeriodo: r.dataFimPeriodo,
            totalRegistros: parseInt(r.totalRegistros),
            totalPerdas: parseInt(r.totalPerdas),
            totalEntradas: parseInt(r.totalEntradas),
            valorPerdas: parseFloat(r.valorPerdas || 0),
        }));
    }
    /**
     * Buscar perdas por lote
     */
    static async getByLote(nomeLote, companyId) {
        const lossRepository = database_1.AppDataSource.getRepository(Loss_1.Loss);
        return await lossRepository.find({
            where: {
                nomeLote,
                companyId,
            },
            order: {
                quantidadeAjuste: 'ASC', // Perdas primeiro (valores negativos)
            },
        });
    }
    /**
     * Buscar perdas agregadas por seção
     */
    static async getAggregatedBySection(nomeLote, companyId) {
        const lossRepository = database_1.AppDataSource.getRepository(Loss_1.Loss);
        const result = await lossRepository
            .createQueryBuilder('loss')
            .select('loss.secao', 'secao')
            .addSelect('loss.secao_nome', 'secaoNome')
            .addSelect('COUNT(*)', 'totalItens')
            .addSelect('SUM(CASE WHEN loss.quantidade_ajuste < 0 THEN 1 ELSE 0 END)', 'totalPerdas')
            .addSelect('SUM(CASE WHEN loss.quantidade_ajuste >= 0 THEN 1 ELSE 0 END)', 'totalEntradas')
            .addSelect('SUM(CASE WHEN loss.quantidade_ajuste < 0 THEN ABS(loss.quantidade_ajuste * loss.custo_reposicao) ELSE 0 END)', 'valorPerdas')
            .addSelect('SUM(CASE WHEN loss.quantidade_ajuste >= 0 THEN (loss.quantidade_ajuste * loss.custo_reposicao) ELSE 0 END)', 'valorEntradas')
            .where('loss.nome_lote = :nomeLote', { nomeLote })
            .andWhere('loss.company_id = :companyId', { companyId })
            .groupBy('loss.secao')
            .addGroupBy('loss.secao_nome')
            .orderBy('valorPerdas', 'DESC')
            .getRawMany();
        return result.map((r) => ({
            secao: r.secao,
            secaoNome: r.secaoNome,
            totalItens: parseInt(r.totalItens),
            totalPerdas: parseInt(r.totalPerdas),
            totalEntradas: parseInt(r.totalEntradas),
            valorPerdas: parseFloat(r.valorPerdas || 0),
            valorEntradas: parseFloat(r.valorEntradas || 0),
        }));
    }
    /**
     * Deletar lote
     */
    static async deleteLote(nomeLote, companyId) {
        const lossRepository = database_1.AppDataSource.getRepository(Loss_1.Loss);
        await lossRepository.delete({
            nomeLote,
            companyId,
        });
        console.log(`🗑️ Lote "${nomeLote}" deletado com sucesso`);
    }
    /**
     * Buscar resultados agregados com filtros
     */
    static async getAgregatedResults(filters) {
        const lossRepository = database_1.AppDataSource.getRepository(Loss_1.Loss);
        const { LossReasonConfig } = await Promise.resolve().then(() => __importStar(require('../entities/LossReasonConfig')));
        const reasonConfigRepository = database_1.AppDataSource.getRepository(LossReasonConfig);
        // Buscar motivos ignorados
        const motivosIgnorados = await reasonConfigRepository.find({
            where: {
                companyId: filters.companyId,
                ignorarCalculo: true,
            },
        });
        const motivosIgnoradosSet = new Set(motivosIgnorados.map(m => m.motivo));
        // Construir query com filtros
        const query = lossRepository
            .createQueryBuilder('loss')
            .where('loss.company_id = :companyId', { companyId: filters.companyId })
            .andWhere('loss.data_importacao >= :dataInicio', { dataInicio: filters.data_inicio })
            .andWhere('loss.data_importacao <= :dataFim', { dataFim: filters.data_fim });
        // Filtro por motivo
        if (filters.motivo && filters.motivo !== 'todos') {
            query.andWhere('loss.descricao_ajuste_completa = :motivo', { motivo: filters.motivo });
        }
        // Filtro por produto (busca parcial na descrição)
        if (filters.produto && filters.produto !== 'todos') {
            query.andWhere('LOWER(loss.descricao_reduzida) LIKE LOWER(:produto)', {
                produto: `%${filters.produto}%`,
            });
        }
        const items = await query.getMany();
        // Separar TODAS as perdas e entradas (incluindo ignorados para mostrar nos cards)
        const todasPerdas = items.filter(i => i.quantidadeAjuste < 0);
        const todasEntradas = items.filter(i => i.quantidadeAjuste >= 0);
        // Perdas NÃO ignoradas (para cálculos de estatísticas)
        const perdasNaoIgnoradas = todasPerdas.filter(i => !motivosIgnoradosSet.has(i.descricaoAjusteCompleta));
        // Entradas NÃO ignoradas (para cálculos de estatísticas)
        const entradasNaoIgnoradas = todasEntradas.filter(i => !motivosIgnoradosSet.has(i.descricaoAjusteCompleta));
        // Calcular totais (apenas com itens NÃO ignorados)
        const totalItens = items.length;
        const totalPerdas = perdasNaoIgnoradas.length;
        const totalEntradas = entradasNaoIgnoradas.length;
        const valorTotalPerdas = perdasNaoIgnoradas.reduce((total, item) => {
            return total + Math.abs(item.quantidadeAjuste * item.custoReposicao);
        }, 0);
        const valorTotalEntradas = entradasNaoIgnoradas.reduce((total, item) => {
            return total + (item.quantidadeAjuste * item.custoReposicao);
        }, 0);
        // Agrupar TODAS as perdas por MOTIVO (incluindo ignorados para exibir nos cards)
        const perdasPorMotivo = {};
        todasPerdas.forEach(item => {
            const motivo = item.descricaoAjusteCompleta || 'Sem descrição';
            const isIgnorado = motivosIgnoradosSet.has(motivo);
            if (!perdasPorMotivo[motivo]) {
                perdasPorMotivo[motivo] = {
                    count: 0,
                    valor: 0,
                    ignorado: isIgnorado,
                };
            }
            perdasPorMotivo[motivo].count++;
            perdasPorMotivo[motivo].valor += Math.abs(item.quantidadeAjuste * item.custoReposicao);
        });
        const motivosRanking = Object.entries(perdasPorMotivo)
            .map(([motivo, stats]) => ({
            motivo,
            totalPerdas: stats.count,
            valorPerdas: stats.valor,
            ignorado: stats.ignorado,
        }))
            .sort((a, b) => b.valorPerdas - a.valorPerdas);
        // Agrupar TODAS as entradas por MOTIVO (incluindo ignorados para exibir nos cards)
        const entradasPorMotivo = {};
        todasEntradas.forEach(item => {
            const motivo = item.descricaoAjusteCompleta || 'Sem descrição';
            const isIgnorado = motivosIgnoradosSet.has(motivo);
            if (!entradasPorMotivo[motivo]) {
                entradasPorMotivo[motivo] = {
                    count: 0,
                    valor: 0,
                    ignorado: isIgnorado,
                };
            }
            entradasPorMotivo[motivo].count++;
            entradasPorMotivo[motivo].valor += (item.quantidadeAjuste * item.custoReposicao);
        });
        const entradasRanking = Object.entries(entradasPorMotivo)
            .map(([motivo, stats]) => ({
            motivo,
            totalEntradas: stats.count,
            valorEntradas: stats.valor,
            ignorado: stats.ignorado,
        }))
            .sort((a, b) => b.valorEntradas - a.valorEntradas);
        // Produtos com maiores perdas e entradas (com paginação)
        const page = filters.page || 1;
        const limit = filters.limit || 50;
        const offset = (page - 1) * limit;
        // Mapear perdas (NÃO ignoradas)
        const perdasMapeadas = perdasNaoIgnoradas.map(item => ({
            codigoBarras: item.codigoBarras,
            descricao: item.descricaoReduzida,
            secao: item.secaoNome || 'Outros',
            quantidade: item.quantidadeAjuste, // Manter negativo para identificar
            custoReposicao: item.custoReposicao,
            valorPerda: Math.abs(item.quantidadeAjuste * item.custoReposicao),
            motivo: item.descricaoAjusteCompleta,
            tipo: 'perda',
        }));
        // Mapear entradas (NÃO ignoradas)
        const entradasMapeadas = entradasNaoIgnoradas.map(item => ({
            codigoBarras: item.codigoBarras,
            descricao: item.descricaoReduzida,
            secao: item.secaoNome || 'Outros',
            quantidade: item.quantidadeAjuste, // Manter positivo para identificar
            custoReposicao: item.custoReposicao,
            valorPerda: item.quantidadeAjuste * item.custoReposicao,
            motivo: item.descricaoAjusteCompleta,
            tipo: 'entrada',
        }));
        // Filtrar por tipo ANTES da paginação
        let todosProdutos = [];
        if (filters.tipo === 'perdas') {
            todosProdutos = perdasMapeadas;
        }
        else if (filters.tipo === 'entradas') {
            todosProdutos = entradasMapeadas;
        }
        else {
            // 'ambos' ou undefined - mostrar tudo
            todosProdutos = [...perdasMapeadas, ...entradasMapeadas];
        }
        const produtosSorted = todosProdutos.sort((a, b) => Math.abs(b.valorPerda) - Math.abs(a.valorPerda));
        const totalProdutos = produtosSorted.length;
        const totalPages = Math.ceil(totalProdutos / limit);
        const produtosRanking = produtosSorted.slice(offset, offset + limit);
        return {
            estatisticas: {
                total_itens: totalItens,
                total_perdas: totalPerdas,
                total_entradas: totalEntradas,
                valor_total_perdas: valorTotalPerdas,
                valor_total_entradas: valorTotalEntradas,
            },
            motivos_ranking: motivosRanking,
            entradas_ranking: entradasRanking,
            produtos_ranking: produtosRanking,
            paginacao: {
                page,
                limit,
                total: totalProdutos,
                totalPages,
            },
        };
    }
    /**
     * Buscar seções únicas para filtro
     */
    static async getUniqueSecoes(companyId) {
        const lossRepository = database_1.AppDataSource.getRepository(Loss_1.Loss);
        const items = await lossRepository
            .createQueryBuilder('loss')
            .select('DISTINCT loss.secao', 'secao')
            .addSelect('loss.secao_nome', 'secaoNome')
            .where('loss.company_id = :companyId', { companyId })
            .andWhere('loss.secao IS NOT NULL')
            .getRawMany();
        return items.map((i) => ({
            secao: i.secao,
            secaoNome: i.secaoNome || 'Outros',
        }));
    }
    /**
     * Buscar produtos únicos para filtro
     */
    static async getUniqueProdutos(companyId) {
        const lossRepository = database_1.AppDataSource.getRepository(Loss_1.Loss);
        const items = await lossRepository
            .createQueryBuilder('loss')
            .select('DISTINCT loss.descricao_reduzida', 'descricao')
            .where('loss.company_id = :companyId', { companyId })
            .andWhere('loss.descricao_reduzida IS NOT NULL')
            .limit(500)
            .getRawMany();
        return items.map((i) => i.descricao);
    }
    /**
     * Buscar motivos únicos
     */
    static async getUniqueMotivos(companyId) {
        const lossRepository = database_1.AppDataSource.getRepository(Loss_1.Loss);
        const items = await lossRepository
            .createQueryBuilder('loss')
            .select('DISTINCT loss.descricao_ajuste_completa', 'motivo')
            .where('loss.company_id = :companyId', { companyId })
            .andWhere('loss.descricao_ajuste_completa IS NOT NULL')
            .getRawMany();
        return items.map((i) => i.motivo);
    }
    /**
     * Alternar motivo ignorado
     */
    static async toggleMotivoIgnorado(motivo, companyId) {
        const { LossReasonConfig } = await Promise.resolve().then(() => __importStar(require('../entities/LossReasonConfig')));
        const reasonConfigRepository = database_1.AppDataSource.getRepository(LossReasonConfig);
        // Verificar se já existe
        const existing = await reasonConfigRepository.findOne({
            where: {
                companyId,
                motivo,
            },
        });
        if (existing) {
            // Alternar o valor
            existing.ignorarCalculo = !existing.ignorarCalculo;
            await reasonConfigRepository.save(existing);
            return existing;
        }
        else {
            // Criar novo com ignorar = true
            const newConfig = reasonConfigRepository.create({
                companyId,
                motivo,
                ignorarCalculo: true,
            });
            await reasonConfigRepository.save(newConfig);
            return newConfig;
        }
    }
    /**
     * Listar motivos ignorados
     */
    static async getMotivosIgnorados(companyId) {
        const { LossReasonConfig } = await Promise.resolve().then(() => __importStar(require('../entities/LossReasonConfig')));
        const reasonConfigRepository = database_1.AppDataSource.getRepository(LossReasonConfig);
        return await reasonConfigRepository.find({
            where: {
                companyId,
                ignorarCalculo: true,
            },
        });
    }
}
exports.LossService = LossService;
//# sourceMappingURL=loss.service.js.map