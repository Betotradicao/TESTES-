import { RuptureSurvey } from '../entities/RuptureSurvey';
import { RuptureSurveyItem } from '../entities/RuptureSurveyItem';
export declare class RuptureSurveyService {
    /**
     * Processa arquivo CSV/Excel e cria pesquisa de ruptura
     */
    static createSurveyFromFile(filePath: string, nomePesquisa: string, userId: string): Promise<RuptureSurvey>;
    /**
     * Atualizar status de um item da pesquisa
     */
    static updateItemStatus(itemId: number, status: 'encontrado' | 'nao_encontrado' | 'ruptura_estoque', verificadoPor: string, observacao?: string): Promise<RuptureSurveyItem>;
    /**
     * Atualizar contadores da pesquisa (itens verificados, encontrados, etc)
     */
    static updateSurveyCounters(surveyId: number): Promise<void>;
    /**
     * Iniciar pesquisa (mudar status para em_andamento)
     */
    static startSurvey(surveyId: number): Promise<RuptureSurvey>;
    /**
     * Buscar pesquisa com itens e estatísticas
     */
    static getSurveyWithStats(surveyId: number): Promise<any>;
    /**
     * Listar todas as pesquisas
     */
    static getAllSurveys(): Promise<RuptureSurvey[]>;
    /**
     * Deletar pesquisa e seus itens
     */
    static deleteSurvey(surveyId: number): Promise<void>;
    /**
     * Buscar resultados agregados de múltiplas pesquisas com filtros
     */
    static getAgregatedResults(filters: {
        data_inicio: string;
        data_fim: string;
        produto?: string;
        fornecedor?: string;
        auditor?: string;
    }): Promise<any>;
    /**
     * Buscar produtos únicos para filtro
     */
    static getUniqueProdutos(): Promise<string[]>;
    /**
     * Buscar fornecedores únicos para filtro
     */
    static getUniqueFornecedores(): Promise<string[]>;
}
//# sourceMappingURL=rupture-survey.service.d.ts.map