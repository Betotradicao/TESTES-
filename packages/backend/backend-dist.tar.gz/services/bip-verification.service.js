"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.BipVerificationService = void 0;
const Bip_1 = require("../entities/Bip");
class BipVerificationService {
    /**
     * Implementa a lógica de matching do N8N
     * Compara bipagens com vendas para determinar quais verificar e quais notificar
     */
    static processVerificationAndNotification(bips, vendas) {
        const to_verify = [];
        const to_notify = [];
        for (const bip of bips) {
            const precoBip = bip.bip_price_cents / 100;
            const productIdInt = parseInt(bip.product_id, 10);
            const match = vendas.find(venda => {
                const codProdutoInt = parseInt(venda.codProduto, 10);
                const valProduto = Number(venda.valTotalProduto);
                // Tolerance of R$ 0.03 as specified in the N8N code
                const precoOk = Math.abs(valProduto - precoBip) <= 0.03;
                return productIdInt === codProdutoInt && precoOk;
            });
            if (match) {
                to_verify.push({
                    bip,
                    venda: match
                });
            }
            else {
                to_notify.push(bip);
            }
        }
        return {
            to_verify,
            to_notify
        };
    }
    /**
     * Processa verificações - atualiza status das bipagens para verified
     * e adiciona tax_cupon da venda correspondente
     */
    static async processVerifications(verifications) {
        console.log(`✅ Processando ${verifications.length} verificações...`);
        const { AppDataSource } = await Promise.resolve().then(() => __importStar(require('../config/database')));
        const bipRepository = AppDataSource.getRepository(Bip_1.Bip);
        for (const { bip, venda } of verifications) {
            try {
                // Update bip status to verified and add tax_cupon
                await bipRepository.update(bip.id, {
                    status: 'verified', // Cast needed due to enum typing
                    tax_cupon: venda.numCupomFiscal?.toString() || null
                });
                console.log(`✅ Bipagem ${bip.id} verificada com cupom ${venda.numCupomFiscal || 'N/A'}`);
            }
            catch (error) {
                console.error(`❌ Erro ao verificar bipagem ${bip.id}:`, error);
            }
        }
        console.log(`🎉 ${verifications.length} bipagens verificadas com sucesso!`);
    }
    /**
     * Processa notificações - atualiza notified_at das bipagens
     */
    static async processNotifications(notifications) {
        console.log(`📢 Processando ${notifications.length} notificações...`);
        const { AppDataSource } = await Promise.resolve().then(() => __importStar(require('../config/database')));
        const bipRepository = AppDataSource.getRepository(Bip_1.Bip);
        for (const bip of notifications) {
            try {
                // Update notified_at to current timestamp
                await bipRepository.update(bip.id, {
                    notified_at: new Date()
                });
                console.log(`📬 Bipagem ${bip.id} marcada como notificada`);
            }
            catch (error) {
                console.error(`❌ Erro ao marcar notificação da bipagem ${bip.id}:`, error);
            }
        }
        console.log(`🎉 ${notifications.length} bipagens marcadas como notificadas!`);
    }
}
exports.BipVerificationService = BipVerificationService;
//# sourceMappingURL=bip-verification.service.js.map