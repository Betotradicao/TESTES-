export declare class TailscaleService {
    /**
     * Obter configurações do Tailscale do banco
     */
    static getConfig(): Promise<{
        vps_ip: any;
        client_ip: any;
        dvr_ip: any;
    }>;
    /**
     * Validar formato de IP Tailscale
     */
    private static validateIP;
    /**
     * Salvar configurações do Tailscale
     */
    static saveConfig(updates: {
        vps_ip?: string;
        client_ip?: string;
    }): Promise<{
        vps_ip: any;
        client_ip: any;
        dvr_ip: any;
    }>;
    /**
     * Testar conectividade completa do Tailscale
     */
    static testConnectivity(): Promise<{
        config: {
            vps_ip: any;
            client_ip: any;
            dvr_ip: any;
        };
        tests: {
            vps_to_client: {
                description: string;
                status: string;
                color: string;
                message: string;
                latency_ms: number | null;
            } | {
                description: string;
                status: string;
                color: string;
                message: any;
                latency_ms: null;
            };
            vps_to_dvr: {
                description: string;
                status: string;
                color: string;
                message: string;
                latency_ms: number | null;
            } | {
                description: string;
                status: string;
                color: string;
                message: any;
                latency_ms: null;
            };
        };
        overall_status: {
            status: string;
            color: string;
            message: string;
        };
    }>;
    /**
     * Testar ping em um IP
     */
    private static pingTest;
    /**
     * Testar conexão HTTP no DVR
     */
    private static httpTest;
    /**
     * Calcular status geral baseado nos testes
     */
    private static calculateOverallStatus;
    /**
     * Helper para inserir ou atualizar configuração
     */
    private static upsertConfig;
}
//# sourceMappingURL=tailscale.service.d.ts.map