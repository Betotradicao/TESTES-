import { CancellationResult } from '../types/webhook.types';
export declare class BipCancellationService {
    /**
     * Verifica se deve cancelar bipagens do mesmo EAN (limite de 3 por dia)
     * Replica exatamente a lógica de cancelamento do N8N
     */
    static checkCancellation(ean: string): Promise<CancellationResult>;
    /**
     * Cancela todas as bipagens do EAN para o dia atual
     * Replica exatamente a query de cancelamento do N8N
     */
    private static cancelBipagesForEan;
}
//# sourceMappingURL=bip-cancellation.service.d.ts.map