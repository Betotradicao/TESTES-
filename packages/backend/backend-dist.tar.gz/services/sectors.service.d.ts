import { Sector } from '../entities/Sector';
import { CreateSectorDto } from '../dtos/create-sector.dto';
import { UpdateSectorDto } from '../dtos/update-sector.dto';
export declare class SectorsService {
    private static generateRandomColor;
    static findAll(onlyActive?: boolean): Promise<Sector[]>;
    static findById(id: number): Promise<Sector>;
    static create(data: CreateSectorDto): Promise<Sector>;
    static update(id: number, data: UpdateSectorDto): Promise<Sector>;
    static toggleStatus(id: number): Promise<Sector>;
}
//# sourceMappingURL=sectors.service.d.ts.map