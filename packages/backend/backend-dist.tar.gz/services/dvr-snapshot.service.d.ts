export declare class DVRSnapshotService {
    /**
     * Captura snapshot de uma câmera do DVR Intelbras
     * @param cameraId ID da câmera (ex: 15 para balança)
     * @returns Path do arquivo de imagem salvo
     */
    captureSnapshot(cameraId: number): Promise<string>;
    /**
     * Captura snapshot e analisa com YOLO
     * @param cameraId ID da câmera
     * @returns Análise YOLO da imagem
     */
    captureAndAnalyze(cameraId: number): Promise<{
        imagePath: string;
        analysis: import("./image-analysis.service").ImageAnalysisResult;
    }>;
}
export declare const dvrSnapshotService: DVRSnapshotService;
//# sourceMappingURL=dvr-snapshot.service.d.ts.map