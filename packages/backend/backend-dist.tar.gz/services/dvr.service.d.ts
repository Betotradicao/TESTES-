import { Sale } from './sales.service';
export interface DVRConfig {
    enabled: boolean;
    dvrIp: string;
    dvrPort: number;
    connectionTimeout: number;
}
export declare class DVRService {
    private static client;
    private static reconnectTimer;
    private static config;
    /**
     * Inicializa a conexão com o DVR
     */
    static initialize(): Promise<void>;
    /**
     * Carrega configurações do banco de dados
     */
    private static loadConfig;
    /**
     * Conecta ao DVR via TCP
     */
    private static connect;
    /**
     * Agenda reconexão automática
     */
    private static scheduleReconnect;
    /**
     * Envia texto formatado para o DVR
     */
    private static sendToDVR;
    /**
     * Formata uma venda no padrão do DVR Intelbras
     * Usa "|" como separador de linha conforme documentação
     */
    private static formatSaleForDVR;
    /**
     * Formata data no padrão YYYYMMDD para DD/MM/YYYY
     */
    private static formatDate;
    /**
     * Extrai hora do timestamp completo
     */
    private static formatTime;
    /**
     * Processa e envia uma venda para o DVR
     */
    static processSale(sale: Sale): Promise<boolean>;
    /**
     * Processa múltiplas vendas
     */
    static processSales(sales: Sale[]): Promise<number>;
    /**
     * Testa a conexão com o DVR
     */
    static testConnection(): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Desconecta do DVR
     */
    static disconnect(): void;
}
//# sourceMappingURL=dvr.service.d.ts.map