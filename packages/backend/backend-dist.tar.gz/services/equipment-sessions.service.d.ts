import { EquipmentSession } from '../entities/EquipmentSession';
export declare class EquipmentSessionsService {
    /**
     * Faz login de um colaborador em um equipamento
     * - Desativa QUALQUER sessão ativa naquele equipamento (desloga colaborador anterior)
     * - Cria nova sessão ativa
     */
    static loginEmployee(equipmentId: number, employeeId: string): Promise<EquipmentSession>;
    /**
     * Faz logout do colaborador logado em um equipamento
     */
    static logoutEmployee(equipmentId: number): Promise<void>;
    /**
     * Retorna a sessão ativa de um equipamento (colaborador logado)
     */
    static getActiveSession(equipmentId: number): Promise<EquipmentSession | null>;
    /**
     * Retorna histórico de sessões de um equipamento
     */
    static getSessionHistory(equipmentId: number, filters?: {
        employeeId?: string;
        startDate?: Date;
        endDate?: Date;
        limit?: number;
        offset?: number;
    }): Promise<{
        sessions: EquipmentSession[];
        total: number;
    }>;
    /**
     * Retorna todas as sessões ativas (para todos os equipamentos)
     */
    static getAllActiveSessions(): Promise<EquipmentSession[]>;
}
//# sourceMappingURL=equipment-sessions.service.d.ts.map