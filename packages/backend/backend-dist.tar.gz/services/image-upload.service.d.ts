import multer from 'multer';
export declare class ImageUploadService {
    private uploadDir;
    constructor();
    private ensureUploadDirExists;
    getMulterConfig(): multer.Multer;
    deleteImage(filename: string): boolean;
    extractFilenameFromUrl(imageUrl: string): string;
}
//# sourceMappingURL=image-upload.service.d.ts.map