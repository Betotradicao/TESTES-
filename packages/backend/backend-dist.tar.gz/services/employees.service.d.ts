import { Employee } from '../entities/Employee';
import { CreateEmployeeDto } from '../dtos/create-employee.dto';
import { UpdateEmployeeDto } from '../dtos/update-employee.dto';
import { EmployeeResponseDto } from '../dtos/employee-response.dto';
export declare class EmployeesService {
    /**
     * Generate unique barcode with prefix 3122 + timestamp/sequential
     */
    private static generateBarcode;
    /**
     * Find all employees with pagination
     */
    static findAll(page?: number, limit?: number, onlyActive?: boolean): Promise<{
        data: EmployeeResponseDto[];
        pagination: {
            page: number;
            limit: number;
            total: number;
            totalPages: number;
        };
    }>;
    /**
     * Find employee by ID
     */
    static findById(id: string): Promise<EmployeeResponseDto>;
    /**
     * Create a new employee
     */
    static create(data: CreateEmployeeDto): Promise<EmployeeResponseDto>;
    /**
     * Update employee
     */
    static update(id: string, data: UpdateEmployeeDto): Promise<EmployeeResponseDto>;
    /**
     * Upload or update employee avatar
     */
    static uploadAvatar(id: string, file: Express.Multer.File): Promise<EmployeeResponseDto>;
    /**
     * Toggle employee active status
     */
    static toggleStatus(id: string): Promise<EmployeeResponseDto>;
    /**
     * Reset employee password (for first access)
     */
    static resetPassword(id: string, newPassword: string): Promise<{
        message: string;
    }>;
    /**
     * Change employee password (employee changes their own password)
     */
    static changePassword(id: string, currentPassword: string, newPassword: string): Promise<{
        message: string;
    }>;
    /**
     * Find employee by barcode
     */
    static findByBarcode(barcode: string): Promise<Employee | null>;
}
//# sourceMappingURL=employees.service.d.ts.map