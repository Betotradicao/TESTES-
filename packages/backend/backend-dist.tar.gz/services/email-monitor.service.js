"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailMonitorService = void 0;
const node_imap_1 = __importDefault(require("node-imap"));
const mailparser_1 = require("mailparser");
const configuration_service_1 = require("./configuration.service");
const database_1 = require("../config/database");
const EmailMonitorLog_1 = require("../entities/EmailMonitorLog");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const axios_1 = __importDefault(require("axios"));
class EmailMonitorService {
    static imap = null;
    static isConnected = false;
    /**
     * Busca configurações do email monitor do banco de dados
     */
    static async getConfig() {
        const email = await configuration_service_1.ConfigurationService.get('email_monitor_email', '');
        const app_password = await configuration_service_1.ConfigurationService.get('email_monitor_app_password', '');
        const subject_filter = await configuration_service_1.ConfigurationService.get('email_monitor_subject_filter', 'DVR');
        const check_interval = await configuration_service_1.ConfigurationService.get('email_monitor_check_interval', '30');
        const whatsapp_group_id = await configuration_service_1.ConfigurationService.get('email_monitor_whatsapp_group', '');
        const enabled = await configuration_service_1.ConfigurationService.get('email_monitor_enabled', 'false');
        return {
            email: email || '',
            app_password: app_password || '',
            subject_filter: subject_filter || 'DVR',
            check_interval_seconds: parseInt(check_interval || '30'),
            whatsapp_group_id: whatsapp_group_id || '',
            enabled: enabled === 'true'
        };
    }
    /**
     * Salva configurações do email monitor
     */
    static async saveConfig(config) {
        if (config.email !== undefined) {
            await configuration_service_1.ConfigurationService.set('email_monitor_email', config.email);
        }
        if (config.app_password !== undefined) {
            await configuration_service_1.ConfigurationService.set('email_monitor_app_password', config.app_password);
        }
        if (config.subject_filter !== undefined) {
            await configuration_service_1.ConfigurationService.set('email_monitor_subject_filter', config.subject_filter);
        }
        if (config.check_interval_seconds !== undefined) {
            await configuration_service_1.ConfigurationService.set('email_monitor_check_interval', config.check_interval_seconds.toString());
        }
        if (config.whatsapp_group_id !== undefined) {
            await configuration_service_1.ConfigurationService.set('email_monitor_whatsapp_group', config.whatsapp_group_id);
        }
        if (config.enabled !== undefined) {
            await configuration_service_1.ConfigurationService.set('email_monitor_enabled', config.enabled.toString());
        }
    }
    /**
     * Conecta ao Gmail via IMAP
     */
    static async connect() {
        const config = await this.getConfig();
        if (!config.email || !config.app_password) {
            throw new Error('Email e App Password não configurados');
        }
        return new Promise((resolve, reject) => {
            const imap = new node_imap_1.default({
                user: config.email,
                password: config.app_password,
                host: 'imap.gmail.com',
                port: 993,
                tls: true,
                tlsOptions: { rejectUnauthorized: false }
            });
            imap.once('ready', () => {
                console.log('✅ Conectado ao Gmail IMAP');
                this.isConnected = true;
                resolve(imap);
            });
            imap.once('error', (err) => {
                console.error('❌ Erro IMAP:', err);
                this.isConnected = false;
                reject(err);
            });
            imap.once('end', () => {
                console.log('📪 Conexão IMAP encerrada');
                this.isConnected = false;
            });
            imap.connect();
        });
    }
    /**
     * Salva anexo de imagem (JPG, PNG, etc)
     */
    static async saveImageAttachment(attachment) {
        try {
            const tempDir = path.join(__dirname, '../../temp');
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }
            // Determine file extension from content type
            let ext = 'jpg';
            if (attachment.contentType?.includes('png')) {
                ext = 'png';
            }
            else if (attachment.contentType?.includes('gif')) {
                ext = 'gif';
            }
            else if (attachment.contentType?.includes('bmp')) {
                ext = 'bmp';
            }
            const tempFile = path.join(tempDir, `image_${Date.now()}.${ext}`);
            fs.writeFileSync(tempFile, attachment.content);
            console.log(`🖼️  Imagem salva temporariamente: ${tempFile}`);
            return tempFile;
        }
        catch (error) {
            console.error('❌ Erro ao salvar imagem:', error);
            return null;
        }
    }
    /**
     * Salva uma cópia permanente da imagem para a galeria
     */
    static async savePermanentImage(tempFilePath) {
        try {
            const uploadsDir = path.join(__dirname, '../../uploads/dvr_images');
            if (!fs.existsSync(uploadsDir)) {
                fs.mkdirSync(uploadsDir, { recursive: true });
            }
            // Gerar nome único para a imagem permanente
            const ext = path.extname(tempFilePath);
            const filename = `dvr_${Date.now()}${ext}`;
            const permanentPath = path.join(uploadsDir, filename);
            // Copiar arquivo temporário para o diretório permanente
            fs.copyFileSync(tempFilePath, permanentPath);
            console.log(`💾 Imagem permanente salva: ${permanentPath}`);
            // Retornar apenas o nome do arquivo (não o caminho completo)
            return filename;
        }
        catch (error) {
            console.error('❌ Erro ao salvar imagem permanente:', error);
            return null;
        }
    }
    /**
     * Extrai imagem de PDF
     */
    static async extractImageFromPDF(pdfBuffer) {
        try {
            // Lazy load pdf-parse para evitar erros de inicialização
            const pdf = require('pdf-parse');
            // Parse PDF
            const data = await pdf(pdfBuffer);
            // Try to find embedded images in PDF
            // Note: pdf-parse doesn't extract images directly, but we can save the PDF
            // and return a base64 string for the entire PDF preview
            // For actual image extraction, we'd need pdf2pic or similar
            // For now, let's save the PDF temporarily and return its path
            const tempDir = path.join(__dirname, '../../temp');
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }
            const tempFile = path.join(tempDir, `pdf_${Date.now()}.pdf`);
            fs.writeFileSync(tempFile, pdfBuffer);
            console.log(`📄 PDF salvo temporariamente: ${tempFile}`);
            console.log(`📝 PDF texto extraído: ${data.text.substring(0, 200)}...`);
            // Return the file path for now
            // In production, you'd want to convert PDF to image using pdf2pic
            return tempFile;
        }
        catch (error) {
            console.error('❌ Erro ao extrair imagem do PDF:', error);
            return null;
        }
    }
    /**
     * Processa um email e envia para WhatsApp
     */
    static async processEmail(mail, config) {
        const logRepository = database_1.AppDataSource.getRepository(EmailMonitorLog_1.EmailMonitorLog);
        try {
            const subject = mail.subject || 'Sem assunto';
            const from = mail.from?.text || 'Desconhecido';
            const textBody = mail.text || '';
            console.log(`📧 Processando email: ${subject} de ${from}`);
            // Check if subject matches filter
            if (!subject.toLowerCase().includes(config.subject_filter.toLowerCase())) {
                console.log(`⏭️  Email ignorado (filtro de assunto não corresponde)`);
                await logRepository.save({
                    email_subject: subject,
                    sender: from,
                    email_body: textBody.substring(0, 500),
                    status: 'skipped',
                    error_message: 'Assunto não corresponde ao filtro',
                    has_attachment: mail.attachments.length > 0,
                    whatsapp_group_id: null
                });
                return;
            }
            // Find PDF or Image attachment
            const pdfAttachment = mail.attachments.find((att) => att.contentType === 'application/pdf');
            const imageAttachment = mail.attachments.find((att) => att.contentType?.startsWith('image/'));
            let filePath = null;
            if (pdfAttachment) {
                // Process PDF
                console.log(`📄 Processando anexo PDF`);
                filePath = await this.extractImageFromPDF(pdfAttachment.content);
                if (!filePath) {
                    throw new Error('Falha ao extrair imagem do PDF');
                }
            }
            else if (imageAttachment) {
                // Process Image directly
                console.log(`🖼️  Processando anexo de imagem`);
                filePath = await this.saveImageAttachment(imageAttachment);
                if (!filePath) {
                    throw new Error('Falha ao salvar imagem');
                }
            }
            else {
                console.log(`⚠️  Email não contém anexo PDF ou imagem`);
                await logRepository.save({
                    email_subject: subject,
                    sender: from,
                    email_body: textBody.substring(0, 500),
                    status: 'error',
                    error_message: 'Nenhum anexo PDF ou imagem encontrado',
                    has_attachment: mail.attachments.length > 0,
                    whatsapp_group_id: config.whatsapp_group_id
                });
                return;
            }
            // Salvar cópia permanente da imagem para a galeria
            const permanentImageFilename = await this.savePermanentImage(filePath);
            // Send to WhatsApp
            await this.sendToWhatsApp(config.whatsapp_group_id, textBody, filePath);
            // Log success
            await logRepository.save({
                email_subject: subject,
                sender: from,
                email_body: textBody.substring(0, 500),
                status: 'success',
                error_message: null,
                has_attachment: true,
                whatsapp_group_id: config.whatsapp_group_id,
                image_path: permanentImageFilename
            });
            console.log(`✅ Email processado e enviado para WhatsApp`);
            // Clean up temp file
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }
        }
        catch (error) {
            console.error(`❌ Erro ao processar email:`, error);
            await logRepository.save({
                email_subject: mail.subject || 'Sem assunto',
                sender: mail.from?.text || 'Desconhecido',
                email_body: mail.text?.substring(0, 500) || '',
                status: 'error',
                error_message: error instanceof Error ? error.message : 'Erro desconhecido',
                has_attachment: mail.attachments.length > 0,
                whatsapp_group_id: config.whatsapp_group_id
            });
        }
    }
    /**
     * Formata o texto do email com emojis para WhatsApp
     */
    static formatEmailText(text) {
        // Adicionar emojis mantendo a formatação original do email
        let formattedText = text
            .replace(/Evento de alarme:/gi, '🧠 Evento de alarme:')
            .replace(/Alarme no Canal No\.:/gi, '📡 Alarme no Canal No.:')
            .replace(/^Nome: FACIAL/gmi, '📱 Nome: FACIAL')
            .replace(/Hor[aá]rio do inicio do alarme\(D\/M\/A H:M:S\):/gi, '🕐 Horário do inicio do alarme(D/M/A H:M:S):')
            .replace(/Nome do dispositivo de alarme:/gi, '📷 Nome do dispositivo de alarme:')
            .replace(/^Nome: Reconhecimento Facial/gmi, '🧑 Nome: Reconhecimento Facial')
            .replace(/End\. IP DVR:/gi, '🌐 End. IP DVR:')
            .replace(/Detalhes do alarme:/gi, '📋 Detalhes do alarme:')
            .replace(/^\s*Modo Comum/gmi, '⚙️ Modo Comum')
            .replace(/^\s*Banco de imagens:/gmi, '📂 Banco de imagens:')
            .replace(/^\s*Nome: (?!FACIAL|Reconhecimento)/gmi, '🧑 Nome: ')
            .replace(/^\s*Similaridade:/gmi, '📊 Similaridade:')
            .replace(/^\s*Idade:/gmi, '🧓 Idade:')
            .replace(/^\s*G[eê]nero:/gmi, '⚧️ Gênero:')
            .replace(/^\s*Express[aã]o:/gmi, '👁️ Expressão:')
            .replace(/^\s*[ÓO]culos:/gmi, '😎 Óculos:')
            .replace(/^\s*M[aá]scara:/gmi, '😷 Máscara:')
            .replace(/^\s*Barba:/gmi, '🧔 Barba:');
        return formattedText;
    }
    /**
     * Envia mensagem e imagem para WhatsApp via Evolution API
     */
    static async sendToWhatsApp(groupId, text, imagePath) {
        try {
            const apiToken = await configuration_service_1.ConfigurationService.get('evolution_api_token', process.env.EVOLUTION_API_TOKEN || '');
            const apiUrl = await configuration_service_1.ConfigurationService.get('evolution_api_url', process.env.EVOLUTION_API_URL || '');
            const instance = await configuration_service_1.ConfigurationService.get('evolution_instance', process.env.EVOLUTION_INSTANCE || '');
            if (!apiToken || !apiUrl || !instance) {
                throw new Error('Configurações Evolution API não encontradas');
            }
            // Read image file
            const imageBuffer = fs.readFileSync(imagePath);
            const base64Image = imageBuffer.toString('base64');
            // Format text with emojis
            const formattedText = this.formatEmailText(text);
            // Send message with image
            const url = `${apiUrl}/message/sendMedia/${instance}`;
            const payload = {
                number: groupId,
                mediatype: 'image',
                mimetype: 'image/jpeg',
                caption: `🚨 ALERTA DVR 🚨\n\n${formattedText}`,
                media: base64Image
            };
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': apiToken
                },
                body: JSON.stringify(payload)
            });
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Evolution API Error: ${response.status} - ${errorText}`);
            }
            console.log(`✅ Mensagem enviada para WhatsApp grupo ${groupId}`);
        }
        catch (error) {
            console.error(`❌ Erro ao enviar para WhatsApp:`, error);
            throw error;
        }
    }
    /**
     * Verifica novos emails (executado pelo cron)
     */
    static async checkNewEmails() {
        const config = await this.getConfig();
        if (!config.enabled) {
            console.log('⏸️  Email monitor desabilitado');
            return;
        }
        if (!config.email || !config.app_password) {
            console.log('⚠️  Email monitor não configurado');
            return;
        }
        let imap = null;
        try {
            console.log('🔍 Verificando novos emails...');
            imap = await this.connect();
            await new Promise((resolve, reject) => {
                imap.openBox('INBOX', false, (err, box) => {
                    if (err) {
                        reject(err);
                        return;
                    }
                    // Search for unseen emails from last 24 hours
                    const searchCriteria = ['UNSEEN', ['SINCE', new Date(Date.now() - 24 * 60 * 60 * 1000)]];
                    const fetchOptions = {
                        bodies: '',
                        markSeen: true
                    };
                    imap.search(searchCriteria, (err, results) => {
                        if (err) {
                            reject(err);
                            return;
                        }
                        if (!results || results.length === 0) {
                            console.log('📭 Nenhum email novo encontrado');
                            resolve();
                            return;
                        }
                        console.log(`📬 ${results.length} emails novos encontrados`);
                        const fetch = imap.fetch(results, fetchOptions);
                        let processed = 0;
                        fetch.on('message', (msg, seqno) => {
                            msg.on('body', async (stream) => {
                                try {
                                    const mail = await (0, mailparser_1.simpleParser)(stream);
                                    await this.processEmail(mail, config);
                                    processed++;
                                    if (processed === results.length) {
                                        resolve();
                                    }
                                }
                                catch (err) {
                                    console.error(`❌ Erro ao parsear email:`, err);
                                }
                            });
                        });
                        fetch.once('error', (err) => {
                            console.error('❌ Erro ao buscar emails:', err);
                            reject(err);
                        });
                        fetch.once('end', () => {
                            console.log('✅ Busca de emails concluída');
                        });
                    });
                });
            });
        }
        catch (error) {
            console.error('❌ Erro ao verificar emails:', error);
        }
        finally {
            if (imap) {
                imap.end();
            }
        }
    }
    /**
     * Testa conexão com Gmail
     */
    static async testConnection() {
        try {
            const config = await this.getConfig();
            if (!config.email || !config.app_password) {
                return {
                    success: false,
                    message: 'Email e App Password devem ser configurados'
                };
            }
            const imap = await this.connect();
            await new Promise((resolve, reject) => {
                imap.openBox('INBOX', true, (err) => {
                    if (err) {
                        reject(err);
                    }
                    else {
                        resolve();
                    }
                });
            });
            imap.end();
            return {
                success: true,
                message: 'Conexão realizada com sucesso!'
            };
        }
        catch (error) {
            return {
                success: false,
                message: error instanceof Error ? error.message : 'Erro desconhecido'
            };
        }
    }
    /**
     * Retorna logs de emails processados
     */
    static async getLogs(limit = 50) {
        const logRepository = database_1.AppDataSource.getRepository(EmailMonitorLog_1.EmailMonitorLog);
        return await logRepository.find({
            order: {
                processed_at: 'DESC'
            },
            take: limit
        });
    }
    /**
     * Reprocessa o último email recebido (para testes)
     */
    static async reprocessLastEmail() {
        const config = await this.getConfig();
        if (!config.enabled) {
            return {
                success: false,
                message: 'Email monitor está desabilitado'
            };
        }
        if (!config.email || !config.app_password) {
            return {
                success: false,
                message: 'Email monitor não está configurado'
            };
        }
        let imap = null;
        try {
            console.log('🔄 Reprocessando último email...');
            imap = await this.connect();
            const result = await new Promise((resolve, reject) => {
                imap.openBox('INBOX', false, (err, box) => {
                    if (err) {
                        reject(err);
                        return;
                    }
                    // Search for last email matching our criteria (seen or unseen)
                    const searchCriteria = config.subject_filter
                        ? [['SUBJECT', config.subject_filter]]
                        : ['ALL'];
                    const fetchOptions = {
                        bodies: '',
                        markSeen: false // Don't mark as seen when reprocessing
                    };
                    imap.search(searchCriteria, (err, results) => {
                        if (err) {
                            reject(err);
                            return;
                        }
                        if (!results || results.length === 0) {
                            resolve({
                                success: false,
                                message: `Nenhum email encontrado com assunto "${config.subject_filter}"`
                            });
                            return;
                        }
                        // Get the last email (most recent)
                        const lastEmailId = results[results.length - 1];
                        console.log(`📧 Reprocessando email ID: ${lastEmailId}`);
                        const fetch = imap.fetch([lastEmailId], fetchOptions);
                        fetch.on('message', (msg, seqno) => {
                            msg.on('body', async (stream) => {
                                try {
                                    const mail = await (0, mailparser_1.simpleParser)(stream);
                                    await this.processEmail(mail, config);
                                    resolve({
                                        success: true,
                                        message: `Email "${mail.subject}" reprocessado com sucesso`
                                    });
                                }
                                catch (err) {
                                    console.error(`❌ Erro ao parsear email:`, err);
                                    resolve({
                                        success: false,
                                        message: `Erro ao processar email: ${err instanceof Error ? err.message : 'Erro desconhecido'}`
                                    });
                                }
                            });
                        });
                        fetch.once('error', (err) => {
                            console.error('❌ Erro ao buscar email:', err);
                            resolve({
                                success: false,
                                message: `Erro ao buscar email: ${err.message}`
                            });
                        });
                    });
                });
            });
            return result;
        }
        catch (error) {
            console.error('❌ Erro ao reprocessar email:', error);
            return {
                success: false,
                message: error instanceof Error ? error.message : 'Erro desconhecido'
            };
        }
        finally {
            if (imap) {
                imap.end();
            }
        }
    }
    /**
     * Busca grupos do WhatsApp via Evolution API
     */
    static async getWhatsAppGroups() {
        try {
            // Buscar configurações da Evolution API
            const evolutionApiUrl = await configuration_service_1.ConfigurationService.get('evolution_api_url', '');
            const evolutionInstance = await configuration_service_1.ConfigurationService.get('evolution_instance', '');
            if (!evolutionApiUrl || !evolutionInstance) {
                throw new Error('Evolution API não configurada');
            }
            // Usar a chave global de autenticação da Evolution
            const globalApiKey = '47de291022054bdb65f49d59579338f7';
            // Fazer requisição para buscar grupos
            const response = await axios_1.default.get(`${evolutionApiUrl}/group/fetchAllGroups/${evolutionInstance}`, {
                params: {
                    getParticipants: 'false'
                },
                headers: {
                    'apikey': globalApiKey
                }
            });
            // Mapear resposta para formato esperado
            const groups = response.data.map((group) => ({
                id: group.id,
                name: group.subject || group.name || 'Sem nome'
            }));
            return groups;
        }
        catch (error) {
            console.error('Erro ao buscar grupos do WhatsApp:', error);
            throw error;
        }
    }
    /**
     * Deletar um log específico e sua imagem associada
     */
    static async deleteLog(logId) {
        try {
            const logRepository = database_1.AppDataSource.getRepository(EmailMonitorLog_1.EmailMonitorLog);
            // Buscar o log
            const log = await logRepository.findOne({ where: { id: logId } });
            if (!log) {
                return {
                    success: false,
                    message: 'Log não encontrado'
                };
            }
            // Deletar arquivo físico da imagem se existir
            if (log.image_path) {
                const uploadsDir = path.join(__dirname, '..', '..', 'uploads', 'dvr_images');
                const imagePath = path.join(uploadsDir, log.image_path);
                try {
                    if (fs.existsSync(imagePath)) {
                        fs.unlinkSync(imagePath);
                        console.log(`🗑️ Imagem deletada: ${log.image_path}`);
                    }
                }
                catch (error) {
                    console.error('Erro ao deletar arquivo de imagem:', error);
                    // Continua mesmo se falhar ao deletar o arquivo
                }
            }
            // Deletar o log do banco
            await logRepository.remove(log);
            return {
                success: true,
                message: 'Log e imagem deletados com sucesso'
            };
        }
        catch (error) {
            console.error('Erro ao deletar log:', error);
            throw error;
        }
    }
}
exports.EmailMonitorService = EmailMonitorService;
//# sourceMappingURL=email-monitor.service.js.map