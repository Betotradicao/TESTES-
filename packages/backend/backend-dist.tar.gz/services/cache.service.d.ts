export declare class CacheService {
    private static readonly CACHE_DIR;
    private static sanitizeKey;
    private static getCacheFilePath;
    private static ensureCacheDir;
    static executeWithCache<T>(cacheKey: string, method: () => Promise<T>): Promise<T>;
    static clearCache(cacheKey?: string): Promise<void>;
}
//# sourceMappingURL=cache.service.d.ts.map