import { Configuration } from '../entities/Configuration';
export declare class ConfigurationService {
    private static configRepository;
    /**
     * Criptografa um valor sensível
     */
    private static encrypt;
    /**
     * Descriptografa um valor sensível
     */
    private static decrypt;
    /**
     * Salva ou atualiza uma configuração
     */
    static set(key: string, value: string, encrypted?: boolean): Promise<Configuration>;
    /**
     * Busca uma configuração
     */
    static get(key: string, defaultValue?: string | null): Promise<string | null>;
    /**
     * Busca todas as configurações
     */
    static getAll(): Promise<Record<string, any>>;
    /**
     * Salva múltiplas configurações de uma vez
     */
    static setMany(configs: Record<string, {
        value: string;
        encrypted?: boolean;
    }>): Promise<void>;
    /**
     * Deleta uma configuração
     */
    static delete(key: string): Promise<boolean>;
    /**
     * Verifica se uma configuração existe
     */
    static has(key: string): Promise<boolean>;
}
//# sourceMappingURL=configuration.service.d.ts.map