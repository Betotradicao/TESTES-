"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CronHealthMonitorService = void 0;
const database_1 = require("../config/database");
const daily_verification_command_1 = require("../commands/daily-verification.command");
/**
 * Monitora a saúde do CRON de verificação
 * Se detectar que não está rodando, reexecuta automaticamente
 */
class CronHealthMonitorService {
    static lastExecutionTime = null;
    static MAX_MINUTES_WITHOUT_EXECUTION = 5; // 5 minutos sem rodar = problema
    /**
     * Atualiza o timestamp da última execução
     */
    static recordExecution() {
        this.lastExecutionTime = new Date();
        console.log(`📝 CRON execution recorded at ${this.lastExecutionTime.toLocaleString('pt-BR')}`);
    }
    /**
     * Verifica se o CRON está saudável (rodando regularmente)
     */
    static getHealthStatus() {
        if (!this.lastExecutionTime) {
            return {
                lastExecution: null,
                isHealthy: false,
                minutesSinceLastRun: null
            };
        }
        const now = new Date();
        const minutesSinceLastRun = Math.floor((now.getTime() - this.lastExecutionTime.getTime()) / 60000);
        const isHealthy = minutesSinceLastRun <= this.MAX_MINUTES_WITHOUT_EXECUTION;
        return {
            lastExecution: this.lastExecutionTime,
            isHealthy,
            minutesSinceLastRun
        };
    }
    /**
     * Auto-recuperação: Se CRON não rodar há muito tempo, força execução
     */
    static async autoRecovery() {
        const status = this.getHealthStatus();
        if (!status.isHealthy) {
            console.log(`⚠️ CRON de verificação não executou há ${status.minutesSinceLastRun} minutos`);
            console.log('🔧 Iniciando auto-recuperação...');
            try {
                await daily_verification_command_1.DailyVerificationCommand.execute(['--notify', 'false']);
                this.recordExecution();
                console.log('✅ Auto-recuperação bem-sucedida!');
            }
            catch (error) {
                console.error('❌ Falha na auto-recuperação:', error);
            }
        }
        else {
            console.log(`💚 CRON saudável - última execução há ${status.minutesSinceLastRun} minutos`);
        }
    }
    /**
     * Salva status no banco de dados para ser exibido no frontend
     */
    static async saveStatusToDatabase() {
        try {
            if (!database_1.AppDataSource.isInitialized) {
                return;
            }
            const status = this.getHealthStatus();
            await database_1.AppDataSource.query(`
        INSERT INTO configurations (key, value, encrypted, created_at, updated_at)
        VALUES
          ('cron_last_execution', $1, false, NOW(), NOW()),
          ('cron_is_healthy', $2, false, NOW(), NOW())
        ON CONFLICT (key) DO UPDATE SET
          value = EXCLUDED.value,
          updated_at = NOW()
      `, [
                status.lastExecution ? status.lastExecution.toISOString() : 'N/A',
                status.isHealthy ? 'true' : 'false'
            ]);
        }
        catch (error) {
            console.error('❌ Erro ao salvar status do CRON:', error);
        }
    }
}
exports.CronHealthMonitorService = CronHealthMonitorService;
//# sourceMappingURL=cron-health-monitor.service.js.map