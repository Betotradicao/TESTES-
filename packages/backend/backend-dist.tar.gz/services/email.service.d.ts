interface SendEmailOptions {
    to: string;
    subject: string;
    html: string;
    text?: string;
}
declare class EmailService {
    private transporter;
    constructor();
    private initializeTransporter;
    sendEmail(options: SendEmailOptions): Promise<boolean>;
    sendPasswordRecoveryEmail(email: string, resetUrl: string, userName: string): Promise<boolean>;
}
export declare const emailService: EmailService;
export {};
//# sourceMappingURL=email.service.d.ts.map