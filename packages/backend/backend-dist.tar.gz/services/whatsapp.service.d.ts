import { Bip } from '../entities/Bip';
export declare class WhatsAppService {
    private static validateEnvironment;
    /**
     * Envia mensagem via Evolution API
     */
    static sendMessage(phoneNumber: string, message: string): Promise<boolean>;
    /**
     * Gera mensagem formatada baseada no template fornecido
     */
    static generateBipMessage(bip: Bip): string;
    /**
     * Envia notificação de bipagem não encontrada
     */
    static sendBipNotification(bip: Bip): Promise<boolean>;
    /**
     * Envia múltiplas notificações com delay entre elas
     */
    static sendMultipleNotifications(bips: Bip[]): Promise<{
        success: number;
        failed: number;
        successfulBips: Bip[];
    }>;
    /**
     * Envia documento PDF via WhatsApp
     */
    static sendDocument(groupId: string, filePath: string, caption?: string): Promise<boolean>;
    /**
     * Envia relatório de auditoria de ruptura para grupo do WhatsApp
     */
    static sendRuptureReport(filePath: string, auditoriaNome: string, totalRupturas: number, naoEncontrado: number, emEstoque: number, perdaVenda?: number, perdaLucro?: number): Promise<boolean>;
}
//# sourceMappingURL=whatsapp.service.d.ts.map