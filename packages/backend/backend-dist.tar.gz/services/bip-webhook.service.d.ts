import { Bip } from '../entities/Bip';
import { EanFormatResult, ErpProduct, BipWebhookData } from '../types/webhook.types';
export declare class BipWebhookService {
    /**
     * Busca produto no ERP usando PLU
     * Reutiliza lógica similar ao ProductsController
     */
    static getProductFromERP(plu: string): Promise<ErpProduct | null>;
    static fetchProductFromERP(plu: string): Promise<ErpProduct | null>;
    /**
     * Processa dados da bipagem conforme N8N
     * Implementa todos os cálculos exatos das imagens
     */
    static processBipData(formatResult: EanFormatResult, erpProduct: ErpProduct, eventDate?: string, equipmentId?: number | null): BipWebhookData;
    /**
     * Salva bipagem no banco de dados
     */
    static saveBipagem(bipData: BipWebhookData, employeeId?: string): Promise<Bip>;
}
//# sourceMappingURL=bip-webhook.service.d.ts.map