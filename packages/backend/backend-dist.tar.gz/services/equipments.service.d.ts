import { Equipment } from '../entities/Equipment';
import { UpdateEquipmentDto } from '../dtos/update-equipment.dto';
export declare class EquipmentsService {
    static findAll(): Promise<Equipment[]>;
    static findById(id: number): Promise<Equipment>;
    static update(id: number, data: UpdateEquipmentDto): Promise<Equipment>;
    static toggleStatus(id: number): Promise<Equipment>;
    /**
     * Extrai o número da porta física do device_path
     * Formato esperado: \\?\HID#VID_XXXX&PID_YYYY#[PORT_NUMBER]&...
     * NOTA: Este número NÃO é a porta USB física, é um ID interno do Windows
     */
    private static extractPortNumber;
    static findOrCreateByScannerId(scanner_machine_id: string, machine_id: string, device_path?: string): Promise<Equipment>;
    static delete(id: number): Promise<{
        message: string;
    }>;
}
//# sourceMappingURL=equipments.service.d.ts.map