"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoUploadService = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const multer_1 = __importDefault(require("multer"));
class VideoUploadService {
    uploadDir;
    constructor() {
        // Pasta onde os vídeos serão salvos
        this.uploadDir = path.join(__dirname, '../../uploads/videos');
        this.ensureUploadDirExists();
    }
    // Garante que a pasta de uploads existe
    ensureUploadDirExists() {
        if (!fs.existsSync(this.uploadDir)) {
            fs.mkdirSync(this.uploadDir, { recursive: true });
            console.log(`📁 Pasta de uploads criada: ${this.uploadDir}`);
        }
    }
    // Configuração do multer para upload
    getMulterConfig() {
        const storage = multer_1.default.diskStorage({
            destination: (req, file, cb) => {
                cb(null, this.uploadDir);
            },
            filename: (req, file, cb) => {
                // Gera nome único: bip_{bipId}_{timestamp}.{extensão}
                const bipId = req.params.id;
                const timestamp = Date.now();
                const ext = path.extname(file.originalname);
                const filename = `bip_${bipId}_${timestamp}${ext}`;
                cb(null, filename);
            }
        });
        const fileFilter = (req, file, cb) => {
            // Aceita apenas vídeos
            const allowedMimes = [
                'video/mp4',
                'video/mpeg',
                'video/quicktime',
                'video/x-msvideo',
                'video/x-ms-wmv',
                'video/webm'
            ];
            if (allowedMimes.includes(file.mimetype)) {
                cb(null, true);
            }
            else {
                cb(new Error('Apenas arquivos de vídeo são permitidos (mp4, mpeg, mov, avi, wmv, webm)'));
            }
        };
        return (0, multer_1.default)({
            storage,
            fileFilter,
            limits: {
                fileSize: 500 * 1024 * 1024 // 500 MB máximo
            }
        });
    }
    // Deleta um vídeo do sistema de arquivos
    deleteVideo(filename) {
        try {
            const filePath = path.join(this.uploadDir, filename);
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                console.log(`🗑️ Vídeo deletado: ${filename}`);
                return true;
            }
            return false;
        }
        catch (error) {
            console.error(`❌ Erro ao deletar vídeo ${filename}:`, error);
            return false;
        }
    }
    // Extrai o nome do arquivo da URL completa
    extractFilenameFromUrl(videoUrl) {
        return path.basename(videoUrl);
    }
}
exports.VideoUploadService = VideoUploadService;
//# sourceMappingURL=video-upload.service.js.map