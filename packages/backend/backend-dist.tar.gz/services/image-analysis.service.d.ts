export interface ImageAnalysisResult {
    coloracao: string;
    coloracao_rgb: string;
    formato: string;
    gordura_visivel: string;
    presenca_osso: boolean;
    confianca: number;
    descricao_detalhada: string;
}
export declare class ImageAnalysisService {
    private yoloServiceUrl;
    constructor();
    /**
     * Analisa uma imagem e extrai características do produto usando YOLO
     */
    analyzeProductImage(imagePath: string): Promise<ImageAnalysisResult>;
    /**
     * Determina o MIME type baseado na extensão do arquivo
     */
    private getMimeType;
    /**
     * Valida se um arquivo é uma imagem válida
     */
    isValidImage(filePath: string): boolean;
    /**
     * Compara duas imagens e retorna score de similaridade (0-100)
     * Usado para validar se o produto pesado é o mesmo da foto de referência
     */
    compareImages(image1Path: string, image2Path: string): Promise<number>;
}
//# sourceMappingURL=image-analysis.service.d.ts.map