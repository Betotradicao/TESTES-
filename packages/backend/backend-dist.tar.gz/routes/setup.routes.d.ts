import { type Router as ExpressRouter } from 'express';
declare const router: ExpressRouter;
export default router;
//# sourceMappingURL=setup.routes.d.ts.map