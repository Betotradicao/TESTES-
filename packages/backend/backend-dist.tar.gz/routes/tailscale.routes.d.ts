import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=tailscale.routes.d.ts.map