import { type Router as RouterType } from 'express';
declare const router: RouterType;
export default router;
//# sourceMappingURL=equipment-sessions.routes.d.ts.map