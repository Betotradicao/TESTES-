import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=products.routes.d.ts.map