"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const email_monitor_controller_1 = require("../controllers/email-monitor.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
const emailMonitorController = new email_monitor_controller_1.EmailMonitorController();
// Todas as rotas requerem autenticação
router.get('/config', auth_1.authenticateToken, emailMonitorController.getConfig.bind(emailMonitorController));
router.put('/config', auth_1.authenticateToken, emailMonitorController.updateConfig.bind(emailMonitorController));
router.post('/test', auth_1.authenticateToken, emailMonitorController.testConnection.bind(emailMonitorController));
router.post('/check', auth_1.authenticateToken, emailMonitorController.checkEmails.bind(emailMonitorController));
router.post('/reprocess-last', auth_1.authenticateToken, emailMonitorController.reprocessLastEmail.bind(emailMonitorController));
router.get('/logs', auth_1.authenticateToken, emailMonitorController.getLogs.bind(emailMonitorController));
router.delete('/logs/:id', auth_1.authenticateToken, emailMonitorController.deleteLog.bind(emailMonitorController));
router.get('/whatsapp-groups', auth_1.authenticateToken, emailMonitorController.getWhatsAppGroups.bind(emailMonitorController));
exports.default = router;
//# sourceMappingURL=email-monitor.routes.js.map