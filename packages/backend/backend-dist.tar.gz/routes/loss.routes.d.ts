import { type Router as ExpressRouter } from 'express';
declare const router: ExpressRouter;
export default router;
//# sourceMappingURL=loss.routes.d.ts.map