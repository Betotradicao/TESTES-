"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const label_audit_controller_1 = require("../controllers/label-audit.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
// Todas as rotas requerem autenticação
router.use(auth_1.authenticateToken);
// Upload e criação de auditoria
router.post('/upload', label_audit_controller_1.upload.single('file'), label_audit_controller_1.LabelAuditController.uploadAndCreateAudit);
// Listar todas as auditorias
router.get('/', label_audit_controller_1.LabelAuditController.getAllAudits);
// Buscar auditoria por ID
router.get('/:id', label_audit_controller_1.LabelAuditController.getAuditById);
// Buscar itens pendentes
router.get('/:id/pending-items', label_audit_controller_1.LabelAuditController.getPendingItems);
// Verificar item
router.put('/items/:itemId/verify', label_audit_controller_1.LabelAuditController.verifyItem);
// Enviar relatório via WhatsApp
router.post('/:id/send-report', label_audit_controller_1.LabelAuditController.sendReport);
// Download PDF
router.get('/:id/report-pdf', label_audit_controller_1.LabelAuditController.downloadReport);
// Deletar auditoria
router.delete('/:id', label_audit_controller_1.LabelAuditController.deleteAudit);
exports.default = router;
//# sourceMappingURL=label-audit.routes.js.map