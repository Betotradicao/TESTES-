"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const tailscale_controller_1 = require("../controllers/tailscale.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
const tailscaleController = new tailscale_controller_1.TailscaleController();
// Todas as rotas requerem autenticação
router.get('/config', auth_1.authenticateToken, tailscaleController.getConfig.bind(tailscaleController));
router.put('/config', auth_1.authenticateToken, tailscaleController.updateConfig.bind(tailscaleController));
router.post('/test', auth_1.authenticateToken, tailscaleController.testConnectivity.bind(tailscaleController));
exports.default = router;
//# sourceMappingURL=tailscale.routes.js.map