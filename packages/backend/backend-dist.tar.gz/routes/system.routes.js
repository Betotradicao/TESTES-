"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const system_controller_1 = require("../controllers/system.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
/**
 * Rotas de configuração do sistema
 * Requer autenticação
 */
// ========================================
// ROTAS DE TOKEN
// ========================================
// Visualizar token atual (apenas admin)
router.get('/token', auth_1.authenticateToken, (req, res) => system_controller_1.SystemController.getToken(req, res));
// Gerar novo token (apenas admin)
router.post('/token/generate', auth_1.authenticateToken, (req, res) => system_controller_1.SystemController.generateToken(req, res));
// Atualizar token (apenas admin)
router.put('/token', auth_1.authenticateToken, (req, res) => system_controller_1.SystemController.updateToken(req, res));
exports.default = router;
//# sourceMappingURL=system.routes.js.map