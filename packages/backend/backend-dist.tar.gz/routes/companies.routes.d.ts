import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=companies.routes.d.ts.map