import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=equipments.routes.d.ts.map