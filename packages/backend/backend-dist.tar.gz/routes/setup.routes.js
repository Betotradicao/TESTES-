"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const setup_controller_1 = require("../controllers/setup.controller");
const router = (0, express_1.Router)();
// Verifica se o sistema precisa de setup
router.get('/status', setup_controller_1.SetupController.checkSetupStatus);
// Realiza o setup inicial
router.post('/initialize', setup_controller_1.SetupController.performSetup);
exports.default = router;
//# sourceMappingURL=setup.routes.js.map