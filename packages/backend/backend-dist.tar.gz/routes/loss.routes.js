"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const loss_controller_1 = require("../controllers/loss.controller");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
// Configurar multer para upload
const upload = (0, multer_1.default)({
    dest: 'uploads/',
    limits: {
        fileSize: 10 * 1024 * 1024, // 10MB
    },
    fileFilter: (req, file, cb) => {
        const allowedTypes = [
            'text/csv',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ];
        if (allowedTypes.includes(file.mimetype) || file.originalname.endsWith('.csv')) {
            cb(null, true);
        }
        else {
            cb(new Error('Apenas arquivos CSV e Excel são permitidos'));
        }
    },
});
// Upload e importação de arquivo
router.post('/upload', auth_1.authenticateToken, upload.single('file'), loss_controller_1.LossController.upload);
// IMPORTANTE: Rotas específicas devem vir ANTES das rotas com parâmetros
// Buscar resultados agregados com filtros
router.get('/agregado', auth_1.authenticateToken, loss_controller_1.LossController.getAgregated);
// Buscar seções únicas para filtro
router.get('/filters/secoes', auth_1.authenticateToken, loss_controller_1.LossController.getSecoes);
// Buscar produtos únicos para filtro
router.get('/filters/produtos', auth_1.authenticateToken, loss_controller_1.LossController.getProdutos);
// Alternar motivo ignorado
router.post('/motivos/toggle', auth_1.authenticateToken, loss_controller_1.LossController.toggleMotivoIgnorado);
// Listar motivos ignorados
router.get('/motivos/ignorados', auth_1.authenticateToken, loss_controller_1.LossController.getMotivosIgnorados);
// Listar todos os lotes
router.get('/', auth_1.authenticateToken, loss_controller_1.LossController.getAllLotes);
// Buscar perdas de um lote
router.get('/:nomeLote/items', auth_1.authenticateToken, loss_controller_1.LossController.getByLote);
// Buscar dados agregados por seção
router.get('/:nomeLote/aggregated', auth_1.authenticateToken, loss_controller_1.LossController.getAggregatedBySection);
// Deletar lote
router.delete('/:nomeLote', auth_1.authenticateToken, loss_controller_1.LossController.deleteLote);
exports.default = router;
//# sourceMappingURL=loss.routes.js.map