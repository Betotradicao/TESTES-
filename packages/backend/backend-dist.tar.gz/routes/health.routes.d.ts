import { Router } from 'express';
declare const router: Router;
export default router;
//# sourceMappingURL=health.routes.d.ts.map