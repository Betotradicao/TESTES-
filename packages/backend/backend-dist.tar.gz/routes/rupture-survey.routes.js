"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const rupture_survey_controller_1 = require("../controllers/rupture-survey.controller");
const auth_1 = require("../middleware/auth");
const multer_1 = __importDefault(require("multer"));
const path = __importStar(require("path"));
const router = (0, express_1.Router)();
// Configurar multer para upload de arquivos
const storage = multer_1.default.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '../../uploads/temp'));
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'rupture-' + uniqueSuffix + path.extname(file.originalname));
    },
});
const upload = (0, multer_1.default)({
    storage,
    fileFilter: (req, file, cb) => {
        const allowedExtensions = ['.csv', '.xlsx', '.xls'];
        const ext = path.extname(file.originalname).toLowerCase();
        if (allowedExtensions.includes(ext)) {
            cb(null, true);
        }
        else {
            cb(new Error('Apenas arquivos CSV e Excel são permitidos'));
        }
    },
    limits: {
        fileSize: 10 * 1024 * 1024, // 10MB
    },
});
// Rotas
router.post('/upload', auth_1.authenticateToken, upload.single('file'), rupture_survey_controller_1.RuptureSurveyController.uploadAndCreate);
router.get('/', auth_1.authenticateToken, rupture_survey_controller_1.RuptureSurveyController.getAll);
// IMPORTANTE: Rotas específicas devem vir ANTES das rotas com parâmetros
router.get('/agregado', auth_1.authenticateToken, rupture_survey_controller_1.RuptureSurveyController.getAgregated);
router.get('/filters/produtos', auth_1.authenticateToken, rupture_survey_controller_1.RuptureSurveyController.getProdutos);
router.get('/filters/fornecedores', auth_1.authenticateToken, rupture_survey_controller_1.RuptureSurveyController.getFornecedores);
router.get('/:id', auth_1.authenticateToken, rupture_survey_controller_1.RuptureSurveyController.getById);
router.post('/:id/start', auth_1.authenticateToken, rupture_survey_controller_1.RuptureSurveyController.startSurvey);
router.post('/:id/finalize', auth_1.authenticateToken, rupture_survey_controller_1.RuptureSurveyController.finalizeSurvey);
router.patch('/items/:itemId/status', auth_1.authenticateToken, rupture_survey_controller_1.RuptureSurveyController.updateItemStatus);
router.delete('/:id', auth_1.authenticateToken, rupture_survey_controller_1.RuptureSurveyController.deleteSurvey);
exports.default = router;
//# sourceMappingURL=rupture-survey.routes.js.map