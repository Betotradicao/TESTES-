"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabelAuditController = exports.upload = void 0;
const label_audit_service_1 = require("../services/label-audit.service");
const multer_1 = __importDefault(require("multer"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
// Configurar multer para upload de arquivos
const storage = multer_1.default.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path_1.default.join(process.cwd(), 'uploads', 'label-audits');
        if (!fs_1.default.existsSync(uploadDir)) {
            fs_1.default.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, `audit-${uniqueSuffix}${path_1.default.extname(file.originalname)}`);
    }
});
exports.upload = (0, multer_1.default)({
    storage,
    fileFilter: (req, file, cb) => {
        const allowedExtensions = ['.csv', '.xls', '.xlsx'];
        const ext = path_1.default.extname(file.originalname).toLowerCase();
        if (allowedExtensions.includes(ext)) {
            cb(null, true);
        }
        else {
            cb(new Error('Apenas arquivos CSV ou Excel são permitidos'));
        }
    }
});
class LabelAuditController {
    /**
     * POST /api/label-audits/upload
     * Upload de arquivo CSV e criação de auditoria
     */
    static async uploadAndCreateAudit(req, res) {
        try {
            if (!req.file) {
                return res.status(400).json({ error: 'Nenhum arquivo enviado' });
            }
            const { titulo, data_referencia } = req.body;
            const userId = req.user?.id || 'system';
            if (!titulo || !data_referencia) {
                return res.status(400).json({ error: 'Título e data de referência são obrigatórios' });
            }
            const audit = await label_audit_service_1.LabelAuditService.createAuditFromFile(req.file.path, titulo, new Date(data_referencia), userId);
            // Deletar arquivo após processamento
            fs_1.default.unlinkSync(req.file.path);
            // Buscar a auditoria completa com contagem de itens
            const auditComplete = await label_audit_service_1.LabelAuditService.getAuditById(audit.id);
            return res.status(201).json({
                message: 'Auditoria criada com sucesso',
                audit: auditComplete
            });
        }
        catch (error) {
            console.error('Erro ao criar auditoria:', error);
            return res.status(500).json({ error: error.message || 'Erro ao processar arquivo' });
        }
    }
    /**
     * GET /api/label-audits
     * Listar todas as auditorias
     */
    static async getAllAudits(req, res) {
        try {
            const audits = await label_audit_service_1.LabelAuditService.getAllAudits();
            return res.json(audits);
        }
        catch (error) {
            console.error('Erro ao listar auditorias:', error);
            return res.status(500).json({ error: error.message });
        }
    }
    /**
     * GET /api/label-audits/:id
     * Buscar auditoria por ID com itens
     */
    static async getAuditById(req, res) {
        try {
            const auditId = parseInt(req.params.id);
            if (isNaN(auditId)) {
                return res.status(400).json({ error: 'ID inválido' });
            }
            const audit = await label_audit_service_1.LabelAuditService.getAuditById(auditId);
            if (!audit) {
                return res.status(404).json({ error: 'Auditoria não encontrada' });
            }
            return res.json(audit);
        }
        catch (error) {
            console.error('Erro ao buscar auditoria:', error);
            return res.status(500).json({ error: error.message });
        }
    }
    /**
     * GET /api/label-audits/:id/pending-items
     * Buscar itens pendentes da auditoria
     */
    static async getPendingItems(req, res) {
        try {
            const auditId = parseInt(req.params.id);
            if (isNaN(auditId)) {
                return res.status(400).json({ error: 'ID inválido' });
            }
            const items = await label_audit_service_1.LabelAuditService.getPendingItems(auditId);
            return res.json(items);
        }
        catch (error) {
            console.error('Erro ao buscar itens pendentes:', error);
            return res.status(500).json({ error: error.message });
        }
    }
    /**
     * PUT /api/label-audits/items/:itemId/verify
     * Verificar item (marcar como correto ou divergente)
     */
    static async verifyItem(req, res) {
        try {
            const itemId = parseInt(req.params.itemId);
            const { status_verificacao, observacao } = req.body;
            const verificadoPor = req.user?.nome || req.user?.email || 'Auditor';
            if (isNaN(itemId)) {
                return res.status(400).json({ error: 'ID inválido' });
            }
            if (!status_verificacao || !['preco_correto', 'preco_divergente'].includes(status_verificacao)) {
                return res.status(400).json({ error: 'Status de verificação inválido' });
            }
            const item = await label_audit_service_1.LabelAuditService.verifyItem(itemId, status_verificacao, verificadoPor, observacao);
            return res.json({
                message: 'Item verificado com sucesso',
                item
            });
        }
        catch (error) {
            console.error('Erro ao verificar item:', error);
            return res.status(500).json({ error: error.message });
        }
    }
    /**
     * POST /api/label-audits/:id/send-report
     * Gerar e enviar relatório de divergentes via WhatsApp
     */
    static async sendReport(req, res) {
        try {
            const auditId = parseInt(req.params.id);
            if (isNaN(auditId)) {
                return res.status(400).json({ error: 'ID inválido' });
            }
            await label_audit_service_1.LabelAuditService.sendDivergentReportToWhatsApp(auditId);
            return res.json({ message: 'Relatório enviado via WhatsApp com sucesso' });
        }
        catch (error) {
            console.error('Erro ao enviar relatório:', error);
            return res.status(500).json({ error: error.message });
        }
    }
    /**
     * GET /api/label-audits/:id/report-pdf
     * Gerar PDF de divergentes para download
     */
    static async downloadReport(req, res) {
        try {
            const auditId = parseInt(req.params.id);
            if (isNaN(auditId)) {
                return res.status(400).json({ error: 'ID inválido' });
            }
            const pdfBuffer = await label_audit_service_1.LabelAuditService.generateDivergentReport(auditId);
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', `attachment; filename=etiquetas_divergentes_${auditId}.pdf`);
            return res.send(pdfBuffer);
        }
        catch (error) {
            console.error('Erro ao gerar PDF:', error);
            return res.status(500).json({ error: error.message });
        }
    }
    /**
     * DELETE /api/label-audits/:id
     * Deletar auditoria
     */
    static async deleteAudit(req, res) {
        try {
            const auditId = parseInt(req.params.id);
            if (isNaN(auditId)) {
                return res.status(400).json({ error: 'ID inválido' });
            }
            await label_audit_service_1.LabelAuditService.deleteAudit(auditId);
            return res.json({ message: 'Auditoria deletada com sucesso' });
        }
        catch (error) {
            console.error('Erro ao deletar auditoria:', error);
            return res.status(500).json({ error: error.message });
        }
    }
}
exports.LabelAuditController = LabelAuditController;
//# sourceMappingURL=label-audit.controller.js.map