"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SectorsController = void 0;
const sectors_service_1 = require("../services/sectors.service");
const create_sector_dto_1 = require("../dtos/create-sector.dto");
const update_sector_dto_1 = require("../dtos/update-sector.dto");
class SectorsController {
    static async getAll(req, res) {
        try {
            const onlyActive = req.query.active === 'true';
            const sectors = await sectors_service_1.SectorsService.findAll(onlyActive);
            res.json(sectors);
        }
        catch (error) {
            console.error('Get all sectors error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async getById(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                return res.status(400).json({ error: 'Invalid sector ID' });
            }
            const sector = await sectors_service_1.SectorsService.findById(id);
            res.json(sector);
        }
        catch (error) {
            console.error('Get sector by ID error:', error);
            if (error.message === 'Sector not found') {
                return res.status(404).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async create(req, res) {
        try {
            const validation = (0, create_sector_dto_1.validateCreateSector)(req.body);
            if (!validation.valid) {
                return res.status(400).json({ errors: validation.errors });
            }
            const sector = await sectors_service_1.SectorsService.create(req.body);
            res.status(201).json(sector);
        }
        catch (error) {
            console.error('Create sector error:', error);
            if (error.message === 'Sector name already exists') {
                return res.status(409).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async update(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                return res.status(400).json({ error: 'Invalid sector ID' });
            }
            const validation = (0, update_sector_dto_1.validateUpdateSector)(req.body);
            if (!validation.valid) {
                return res.status(400).json({ errors: validation.errors });
            }
            const sector = await sectors_service_1.SectorsService.update(id, req.body);
            res.json(sector);
        }
        catch (error) {
            console.error('Update sector error:', error);
            if (error.message === 'Sector not found') {
                return res.status(404).json({ error: error.message });
            }
            if (error.message === 'Sector name already exists') {
                return res.status(409).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
    static async toggle(req, res) {
        try {
            const id = parseInt(req.params.id);
            if (isNaN(id)) {
                return res.status(400).json({ error: 'Invalid sector ID' });
            }
            const sector = await sectors_service_1.SectorsService.toggleStatus(id);
            res.json(sector);
        }
        catch (error) {
            console.error('Toggle sector error:', error);
            if (error.message === 'Sector not found') {
                return res.status(404).json({ error: error.message });
            }
            res.status(500).json({ error: 'Internal server error' });
        }
    }
}
exports.SectorsController = SectorsController;
//# sourceMappingURL=sectors.controller.js.map