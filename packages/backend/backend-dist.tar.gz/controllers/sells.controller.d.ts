import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare class SellsController {
    static getSells(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
}
//# sourceMappingURL=sells.controller.d.ts.map