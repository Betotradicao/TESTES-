import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare class ProductsController {
    static getProducts(req: AuthRequest, res: Response): Promise<void>;
    static activateProduct(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static bulkActivateProducts(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Upload de foto e análise automática por IA
     * POST /api/products/:id/upload-photo
     */
    static uploadAndAnalyzePhoto(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Atualizar características de IA do produto
     * PUT /api/products/:id/ai-characteristics
     */
    static updateAICharacteristics(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Captura foto da câmera do DVR e analisa com YOLO
     * POST /api/products/:id/capture-from-camera
     */
    static captureFromCamera(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
}
//# sourceMappingURL=products.controller.d.ts.map