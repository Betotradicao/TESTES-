"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuptureSurveyController = void 0;
const rupture_survey_service_1 = require("../services/rupture-survey.service");
const fs = __importStar(require("fs"));
class RuptureSurveyController {
    /**
     * Upload de arquivo CSV e criação de pesquisa
     */
    static async uploadAndCreate(req, res) {
        try {
            if (!req.file) {
                return res.status(400).json({ error: 'Nenhum arquivo enviado' });
            }
            const { nome_pesquisa } = req.body;
            if (!nome_pesquisa) {
                // Remover arquivo temporário
                fs.unlinkSync(req.file.path);
                return res.status(400).json({ error: 'Nome da pesquisa é obrigatório' });
            }
            const userId = req.user.id;
            // Processar arquivo
            const survey = await rupture_survey_service_1.RuptureSurveyService.createSurveyFromFile(req.file.path, nome_pesquisa, userId);
            // Remover arquivo temporário
            fs.unlinkSync(req.file.path);
            res.json({
                message: 'Pesquisa criada com sucesso',
                survey,
            });
        }
        catch (error) {
            console.error('❌ Erro ao criar pesquisa:', error);
            // Tentar remover arquivo temporário em caso de erro
            if (req.file && fs.existsSync(req.file.path)) {
                fs.unlinkSync(req.file.path);
            }
            res.status(500).json({
                error: error.message || 'Erro ao processar arquivo',
            });
        }
    }
    /**
     * Listar todas as pesquisas
     */
    static async getAll(req, res) {
        try {
            const surveys = await rupture_survey_service_1.RuptureSurveyService.getAllSurveys();
            res.json(surveys);
        }
        catch (error) {
            console.error('❌ Erro ao listar pesquisas:', error);
            res.status(500).json({ error: error.message });
        }
    }
    /**
     * Buscar pesquisa por ID com estatísticas
     */
    static async getById(req, res) {
        try {
            const { id } = req.params;
            const survey = await rupture_survey_service_1.RuptureSurveyService.getSurveyWithStats(parseInt(id));
            res.json(survey);
        }
        catch (error) {
            console.error('❌ Erro ao buscar pesquisa:', error);
            res.status(500).json({ error: error.message });
        }
    }
    /**
     * Iniciar pesquisa (mudar para em_andamento)
     */
    static async startSurvey(req, res) {
        try {
            const { id } = req.params;
            const survey = await rupture_survey_service_1.RuptureSurveyService.startSurvey(parseInt(id));
            res.json({
                message: 'Pesquisa iniciada',
                survey,
            });
        }
        catch (error) {
            console.error('❌ Erro ao iniciar pesquisa:', error);
            res.status(500).json({ error: error.message });
        }
    }
    /**
     * Atualizar status de um item (usado pelo mobile)
     */
    static async updateItemStatus(req, res) {
        try {
            const { itemId } = req.params;
            const { status, verificado_por, observacao } = req.body;
            if (!status || !verificado_por) {
                return res.status(400).json({
                    error: 'Status e verificado_por são obrigatórios',
                });
            }
            const item = await rupture_survey_service_1.RuptureSurveyService.updateItemStatus(parseInt(itemId), status, verificado_por, observacao);
            res.json({
                message: 'Item atualizado',
                item,
            });
        }
        catch (error) {
            console.error('❌ Erro ao atualizar item:', error);
            res.status(500).json({ error: error.message });
        }
    }
    /**
     * Deletar pesquisa
     */
    static async deleteSurvey(req, res) {
        try {
            const { id } = req.params;
            await rupture_survey_service_1.RuptureSurveyService.deleteSurvey(parseInt(id));
            res.json({
                message: 'Pesquisa deletada com sucesso',
            });
        }
        catch (error) {
            console.error('❌ Erro ao deletar pesquisa:', error);
            res.status(500).json({ error: error.message });
        }
    }
    /**
     * Buscar resultados agregados com filtros
     */
    static async getAgregated(req, res) {
        try {
            const { data_inicio, data_fim, produto, fornecedor, auditor } = req.query;
            console.log('📊 Filtros recebidos:', { data_inicio, data_fim, produto, fornecedor, auditor });
            if (!data_inicio || !data_fim) {
                return res.status(400).json({
                    error: 'data_inicio e data_fim são obrigatórios',
                });
            }
            const results = await rupture_survey_service_1.RuptureSurveyService.getAgregatedResults({
                data_inicio: data_inicio,
                data_fim: data_fim,
                produto: produto,
                fornecedor: fornecedor,
                auditor: auditor,
            });
            console.log('✅ Resultados agregados calculados com sucesso');
            res.json(results);
        }
        catch (error) {
            console.error('❌ Erro ao buscar resultados agregados:', error);
            console.error('Stack trace:', error.stack);
            res.status(500).json({ error: error.message });
        }
    }
    /**
     * Buscar produtos únicos para filtro
     */
    static async getProdutos(req, res) {
        try {
            const produtos = await rupture_survey_service_1.RuptureSurveyService.getUniqueProdutos();
            res.json(produtos);
        }
        catch (error) {
            console.error('❌ Erro ao buscar produtos:', error);
            res.status(500).json({ error: error.message });
        }
    }
    /**
     * Buscar fornecedores únicos para filtro
     */
    static async getFornecedores(req, res) {
        try {
            const fornecedores = await rupture_survey_service_1.RuptureSurveyService.getUniqueFornecedores();
            res.json(fornecedores);
        }
        catch (error) {
            console.error('❌ Erro ao buscar fornecedores:', error);
            res.status(500).json({ error: error.message });
        }
    }
}
exports.RuptureSurveyController = RuptureSurveyController;
//# sourceMappingURL=rupture-survey.controller.js.map