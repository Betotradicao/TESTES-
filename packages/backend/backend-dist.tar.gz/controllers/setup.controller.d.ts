import { Request, Response } from 'express';
export declare class SetupController {
    static checkSetupStatus(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    static performSetup(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
//# sourceMappingURL=setup.controller.d.ts.map