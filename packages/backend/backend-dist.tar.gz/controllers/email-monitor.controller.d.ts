import { Request, Response } from 'express';
export declare class EmailMonitorController {
    /**
     * GET /api/email-monitor/config
     * Buscar configurações do email monitor
     */
    getConfig(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * PUT /api/email-monitor/config
     * Atualizar configurações do email monitor
     */
    updateConfig(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * POST /api/email-monitor/test
     * Testar conexão com Gmail
     */
    testConnection(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * POST /api/email-monitor/check
     * Verificar emails manualmente (para teste)
     */
    checkEmails(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * GET /api/email-monitor/logs
     * Buscar logs de emails processados
     */
    getLogs(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * GET /api/email-monitor/whatsapp-groups
     * Buscar grupos do WhatsApp via Evolution API
     */
    getWhatsAppGroups(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * POST /api/email-monitor/reprocess-last
     * Reprocessar o último email recebido (para testes)
     */
    reprocessLastEmail(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * DELETE /api/email-monitor/logs/:id
     * Deletar um log específico e sua imagem associada
     */
    deleteLog(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
//# sourceMappingURL=email-monitor.controller.d.ts.map