import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare class BipsController {
    static getBips(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static cancelBip(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static reactivateBip(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static getEmployeesWithBips(req: AuthRequest, res: Response): Promise<void>;
    static uploadVideo(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static deleteVideo(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static uploadImage(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    static deleteImage(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
}
//# sourceMappingURL=bips.controller.d.ts.map