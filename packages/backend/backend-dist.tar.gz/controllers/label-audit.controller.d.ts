import { Request, Response } from 'express';
import multer from 'multer';
export declare const upload: multer.Multer;
export declare class LabelAuditController {
    /**
     * POST /api/label-audits/upload
     * Upload de arquivo CSV e criação de auditoria
     */
    static uploadAndCreateAudit(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * GET /api/label-audits
     * Listar todas as auditorias
     */
    static getAllAudits(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * GET /api/label-audits/:id
     * Buscar auditoria por ID com itens
     */
    static getAuditById(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * GET /api/label-audits/:id/pending-items
     * Buscar itens pendentes da auditoria
     */
    static getPendingItems(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * PUT /api/label-audits/items/:itemId/verify
     * Verificar item (marcar como correto ou divergente)
     */
    static verifyItem(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * POST /api/label-audits/:id/send-report
     * Gerar e enviar relatório de divergentes via WhatsApp
     */
    static sendReport(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * GET /api/label-audits/:id/report-pdf
     * Gerar PDF de divergentes para download
     */
    static downloadReport(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * DELETE /api/label-audits/:id
     * Deletar auditoria
     */
    static deleteAudit(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
//# sourceMappingURL=label-audit.controller.d.ts.map