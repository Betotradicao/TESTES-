import { Request, Response } from 'express';
export declare class TailscaleController {
    /**
     * GET /api/tailscale/config
     * Obter configurações do Tailscale
     */
    getConfig(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * PUT /api/tailscale/config
     * Atualizar configurações do Tailscale
     */
    updateConfig(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * POST /api/tailscale/test
     * Testar conectividade do Tailscale
     */
    testConnectivity(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
//# sourceMappingURL=tailscale.controller.d.ts.map