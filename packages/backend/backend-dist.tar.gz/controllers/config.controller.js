"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigController = void 0;
const pg_1 = require("pg");
const configuration_service_1 = require("../services/configuration.service");
class ConfigController {
    async testDatabaseConnection(req, res) {
        const { host, port, username, password, databaseName } = req.body;
        if (!username || !password) {
            return res.status(400).json({
                success: false,
                message: 'Usuário e senha são obrigatórios'
            });
        }
        // Usar credenciais internas do Docker para teste (backend está dentro da rede Docker)
        const client = new pg_1.Client({
            host: process.env.DB_HOST || 'postgres',
            port: parseInt(process.env.DB_PORT || '5432'),
            user: username,
            password,
            database: databaseName || process.env.DB_NAME || 'postgres'
        });
        try {
            await client.connect();
            // Testa uma query simples
            const result = await client.query('SELECT version()');
            await client.end();
            return res.json({
                success: true,
                message: 'Conexão estabelecida com sucesso!',
                version: result.rows[0].version,
                connection: {
                    host,
                    port: parseInt(port) || 5432,
                    database: databaseName || 'postgres'
                }
            });
        }
        catch (error) {
            try {
                await client.end();
            }
            catch (e) {
                // Ignore error closing connection
            }
            return res.status(500).json({
                success: false,
                message: `Erro ao conectar: ${error.message}`,
                error: error.code || 'UNKNOWN_ERROR'
            });
        }
    }
    async testMinioConnection(req, res) {
        const { endpoint, port, accessKey, secretKey, useSSL } = req.body;
        if (!accessKey || !secretKey) {
            return res.status(400).json({
                success: false,
                message: 'Access Key e Secret Key são obrigatórios'
            });
        }
        try {
            // Importa o MinIO dinamicamente
            const Minio = require('minio');
            // Usar credenciais internas do Docker para teste (backend está dentro da rede Docker)
            // Sempre usar as credenciais do environment (MINIO_ROOT_USER/PASSWORD) para garantir que funcione
            const minioClient = new Minio.Client({
                endPoint: process.env.MINIO_ENDPOINT || 'minio',
                port: parseInt(process.env.MINIO_PORT || '9000'),
                useSSL: (process.env.MINIO_USE_SSL || 'false') === 'true',
                accessKey: process.env.MINIO_ROOT_USER || process.env.MINIO_ACCESS_KEY || accessKey,
                secretKey: process.env.MINIO_ROOT_PASSWORD || process.env.MINIO_SECRET_KEY || secretKey
            });
            // Testa listando os buckets
            const buckets = await minioClient.listBuckets();
            return res.json({
                success: true,
                message: 'Conexão com MinIO estabelecida com sucesso!',
                buckets: buckets.map((b) => ({
                    name: b.name,
                    creationDate: b.creationDate
                })),
                connection: {
                    endpoint,
                    port: parseInt(port) || 9000,
                    useSSL: useSSL || false
                }
            });
        }
        catch (error) {
            return res.status(500).json({
                success: false,
                message: `Erro ao conectar ao MinIO: ${error.message}`,
                error: error.code || 'UNKNOWN_ERROR'
            });
        }
    }
    async testZanthusConnection(req, res) {
        const { apiUrl, port, apiToken, endpoint } = req.body;
        if (!apiUrl) {
            return res.status(400).json({
                success: false,
                message: 'URL da API é obrigatória'
            });
        }
        try {
            const axios = require('axios');
            const URLSearchParams = require('url').URLSearchParams;
            // Monta a URL completa
            const baseUrl = port ? `${apiUrl}:${port}` : apiUrl;
            const fullUrl = endpoint ? `${baseUrl}${endpoint}` : `${baseUrl}/manager/restful/integracao/cadastro_sincrono.php5`;
            // Query SQL para buscar produtos
            const sqlProdutos = "SELECT * FROM TAB_PRODUTO WHERE ROWNUM <= 5";
            // Query SQL para buscar vendas (ontem, para garantir que há dados)
            const ontem = new Date();
            ontem.setDate(ontem.getDate() - 1);
            const dataOntem = ontem.toISOString().split('T')[0];
            const sqlVendas = `
        SELECT
          z.M00AC as codCaixa,
          z.M00ZA as codLoja,
          z.M43AH as codProduto,
          z.M00AF as dtaSaida,
          z.M00AD as numCupomFiscal,
          z.M43DQ as valVenda,
          z.M43AO as qtdTotalProduto,
          z.M43AP as valTotalProduto,
          p.DESCRICAO_PRODUTO as desProduto
        FROM ZAN_M43 z
        LEFT JOIN TAB_PRODUTO p ON p.COD_PRODUTO LIKE '%' || z.M43AH
        WHERE TRUNC(z.M00AF) = TO_DATE('${dataOntem}','YYYY-MM-DD')
        AND ROWNUM <= 5
      `.replace(/\s+/g, ' ').trim();
            const config = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                timeout: 10000 // 10 segundos
            };
            // Nota: Token não é usado pois causa erro 500 na API Zanthus
            // if (apiToken) {
            //   config.headers['Authorization'] = `Bearer ${apiToken}`;
            // }
            // Requisição 1: Produtos
            const jsonDataProdutos = {
                ZMI: {
                    DATABASES: {
                        DATABASE: {
                            "@attributes": {
                                NAME: "MANAGER",
                                AUTOCOMMIT_VALUE: "1000",
                                AUTOCOMMIT_ENABLED: "1",
                                HALTONERROR: "1"
                            },
                            COMMANDS: {
                                SELECT: {
                                    PRODUTOS: {
                                        PRODUTO: {
                                            SQL: sqlProdutos
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            };
            const formDataProdutos = new URLSearchParams();
            formDataProdutos.append('str_json', JSON.stringify(jsonDataProdutos));
            // Requisição 2: Vendas
            const jsonDataVendas = {
                ZMI: {
                    DATABASES: {
                        DATABASE: {
                            "@attributes": {
                                NAME: "MANAGER",
                                AUTOCOMMIT_VALUE: "1000",
                                AUTOCOMMIT_ENABLED: "1",
                                HALTONERROR: "1"
                            },
                            COMMANDS: {
                                SELECT: {
                                    MERCADORIAS: {
                                        MERCADORIA: {
                                            SQL: sqlVendas
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            };
            const formDataVendas = new URLSearchParams();
            formDataVendas.append('str_json', JSON.stringify(jsonDataVendas));
            // Faz as duas requisições em paralelo
            const [responseProdutos, responseVendas] = await Promise.all([
                axios.post(fullUrl, formDataProdutos.toString(), config),
                axios.post(fullUrl, formDataVendas.toString(), config)
            ]);
            const produtosContent = responseProdutos.data?.QUERY?.CONTENT;
            const vendasContent = responseVendas.data?.QUERY?.CONTENT;
            const firstProduct = Array.isArray(produtosContent) ? produtosContent[0] : produtosContent;
            const firstSale = Array.isArray(vendasContent) ? vendasContent[0] : vendasContent;
            return res.json({
                success: true,
                message: 'Conexão OK! API Zanthus respondeu.',
                data: {
                    products: {
                        endpoint: fullUrl,
                        sample: firstProduct,
                        total: Array.isArray(produtosContent) ? produtosContent.length : 1
                    },
                    sales: {
                        endpoint: fullUrl,
                        sample: firstSale,
                        total: Array.isArray(vendasContent) ? vendasContent.length : (vendasContent ? 1 : 0)
                    }
                }
            });
        }
        catch (error) {
            return res.status(500).json({
                success: false,
                message: `Erro ao conectar: ${error.message}`,
                data: {
                    error: error.code || 'UNKNOWN_ERROR',
                    status: error.response?.status,
                    statusText: error.response?.statusText,
                    responseData: error.response?.data
                }
            });
        }
    }
    async testIntersolidConnection(req, res) {
        const { apiUrl, port, username, password, salesEndpoint, productsEndpoint } = req.body;
        if (!apiUrl || !salesEndpoint) {
            return res.status(400).json({
                success: false,
                message: 'URL da API e Endpoint de Vendas são obrigatórios'
            });
        }
        try {
            const axios = require('axios');
            // Monta a URL completa
            const baseUrl = port ? `${apiUrl}:${port}` : apiUrl;
            // Pega a data de hoje no formato YYYYMMDD
            const hoje = new Date();
            const ano = hoje.getFullYear();
            const mes = String(hoje.getMonth() + 1).padStart(2, '0');
            const dia = String(hoje.getDate()).padStart(2, '0');
            const dataFormatada = `${ano}${mes}${dia}`; // formato YYYYMMDD
            // Adiciona parâmetros de data às URLs
            const salesUrl = `${baseUrl}${salesEndpoint}?dta_de=${dataFormatada}&dta_ate=${dataFormatada}`;
            const productsUrl = productsEndpoint ? `${baseUrl}${productsEndpoint}` : null;
            const config = {
                timeout: 10000 // 10 segundos
            };
            // Adiciona autenticação Basic se tiver usuário e senha
            if (username && password) {
                config.auth = {
                    username,
                    password
                };
            }
            // Faz as requisições (vendas e produtos se disponível)
            const promises = [axios.get(salesUrl, config)];
            if (productsUrl) {
                promises.push(axios.get(productsUrl, config));
            }
            const responses = await Promise.all(promises);
            const sales = responses[0].data;
            const firstSale = Array.isArray(sales) ? sales[0] : sales;
            const result = {
                success: true,
                message: 'Conexão OK! API Intersolid respondeu.',
                data: {
                    sales: {
                        endpoint: salesUrl,
                        sample: firstSale,
                        total: Array.isArray(sales) ? sales.length : 1
                    }
                }
            };
            // Adiciona dados de produtos se houver
            if (productsUrl && responses[1]) {
                const products = responses[1].data;
                const firstProduct = Array.isArray(products) ? products[0] : products;
                result.data.products = {
                    endpoint: productsUrl,
                    sample: firstProduct,
                    total: Array.isArray(products) ? products.length : 1
                };
            }
            return res.json(result);
        }
        catch (error) {
            return res.status(500).json({
                success: false,
                message: `Erro ao conectar: ${error.message}`,
                data: {
                    error: error.code || 'UNKNOWN_ERROR',
                    status: error.response?.status,
                    statusText: error.response?.statusText,
                    responseData: error.response?.data,
                    fullUrl: `${port ? `${apiUrl}:${port}` : apiUrl}${salesEndpoint}`
                }
            });
        }
    }
    async saveConfigurations(req, res) {
        try {
            const configurations = req.body;
            if (!configurations || typeof configurations !== 'object') {
                return res.status(400).json({
                    success: false,
                    message: 'Configurações inválidas'
                });
            }
            // Define quais campos devem ser criptografados
            const encryptedFields = [
                'zanthus_api_token',
                'intersolid_password',
                'evolution_api_token',
                'database_password',
                'minio_access_key',
                'minio_secret_key'
            ];
            const configsToSave = {};
            for (const [key, value] of Object.entries(configurations)) {
                if (value !== null && value !== undefined && value !== '') {
                    configsToSave[key] = {
                        value: String(value),
                        encrypted: encryptedFields.includes(key)
                    };
                }
            }
            await configuration_service_1.ConfigurationService.setMany(configsToSave);
            // Se salvou configurações do MinIO, reinicializar o cliente
            const minioConfigKeys = ['minio_endpoint', 'minio_port', 'minio_access_key', 'minio_secret_key', 'minio_use_ssl', 'minio_bucket_name'];
            const hasMinioConfig = Object.keys(configsToSave).some(key => minioConfigKeys.includes(key));
            if (hasMinioConfig) {
                try {
                    // Importar dinamicamente para evitar dependência circular
                    const { minioService } = await Promise.resolve().then(() => __importStar(require('../services/minio.service')));
                    await minioService.reinitialize();
                    console.log('✅ MinIO client reinitialized after configuration update');
                }
                catch (error) {
                    console.error('⚠️ Failed to reinitialize MinIO client:', error);
                    // Não falha o save, apenas loga o erro
                }
            }
            return res.json({
                success: true,
                message: 'Configurações salvas com sucesso!'
            });
        }
        catch (error) {
            console.error('Erro ao salvar configurações:', error);
            return res.status(500).json({
                success: false,
                message: `Erro ao salvar configurações: ${error.message}`
            });
        }
    }
    async getConfigurations(req, res) {
        try {
            const configs = await configuration_service_1.ConfigurationService.getAll();
            return res.json({
                success: true,
                data: configs
            });
        }
        catch (error) {
            console.error('Erro ao buscar configurações:', error);
            return res.status(500).json({
                success: false,
                message: `Erro ao buscar configurações: ${error.message}`
            });
        }
    }
}
exports.ConfigController = ConfigController;
//# sourceMappingURL=config.controller.js.map