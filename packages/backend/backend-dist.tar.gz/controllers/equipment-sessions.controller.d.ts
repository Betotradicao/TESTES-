import { Request, Response } from 'express';
export declare class EquipmentSessionsController {
    /**
     * Retorna todas as sessões ativas (todos os equipamentos com colaborador logado)
     * GET /api/equipment-sessions/active
     */
    static getAllActiveSessions(req: Request, res: Response): Promise<void>;
    /**
     * Retorna a sessão ativa de um equipamento específico
     * GET /api/equipment-sessions/equipment/:equipmentId
     */
    static getActiveSessionByEquipment(req: Request, res: Response): Promise<void>;
    /**
     * Retorna o histórico de sessões de um equipamento
     * GET /api/equipment-sessions/equipment/:equipmentId/history
     * Query params: employeeId, startDate, endDate, page, limit
     */
    static getSessionHistory(req: Request, res: Response): Promise<void>;
    /**
     * Faz login manual de um colaborador em um equipamento
     * POST /api/equipment-sessions/login
     * Body: { equipmentId: number, employeeId: string }
     */
    static loginEmployee(req: Request, res: Response): Promise<void>;
    /**
     * Faz logout manual do colaborador logado em um equipamento
     * POST /api/equipment-sessions/logout/:equipmentId
     */
    static logoutEmployee(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=equipment-sessions.controller.d.ts.map