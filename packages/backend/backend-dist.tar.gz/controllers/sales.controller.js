"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesController = void 0;
const sales_service_1 = require("../services/sales.service");
class SalesController {
    static async getSales(req, res) {
        try {
            const { from, to } = req.query;
            // Validate required parameters
            if (!from || !to) {
                return res.status(400).json({
                    error: 'Parameters from and to are required in format YYYY-MM-DD'
                });
            }
            // Validate date format (YYYY-MM-DD)
            if (!sales_service_1.SalesService.validateDateFormat(from) || !sales_service_1.SalesService.validateDateFormat(to)) {
                return res.status(400).json({
                    error: 'Dates must be in format YYYY-MM-DD'
                });
            }
            // Convert dates from YYYY-MM-DD to YYYYMMDD for ERP API
            const fromFormatted = sales_service_1.SalesService.formatDateToERP(from);
            const toFormatted = sales_service_1.SalesService.formatDateToERP(to);
            // Fetch sales from ERP using service
            const erpSales = await sales_service_1.SalesService.fetchSalesFromERP(fromFormatted, toFormatted);
            res.json({
                data: erpSales,
                total: erpSales.length,
                filters: {
                    from: from,
                    to: to
                }
            });
        }
        catch (error) {
            console.error('Get sales error:', error);
            res.status(500).json({ error: 'Internal server error' });
        }
    }
}
exports.SalesController = SalesController;
//# sourceMappingURL=sales.controller.js.map