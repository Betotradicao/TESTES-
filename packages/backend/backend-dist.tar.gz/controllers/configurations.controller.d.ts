import { Request, Response } from 'express';
export declare class ConfigurationsController {
    /**
     * GET /api/configurations
     * Buscar todas as configurações
     */
    index(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * GET /api/configurations/:key
     * Buscar configuração específica por chave
     */
    show(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * PUT /api/configurations/:key
     * Atualizar configuração específica
     */
    update(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * GET /api/configurations/email
     * Buscar configurações de email (do banco de dados)
     */
    getEmailConfig(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
    /**
     * PUT /api/configurations/email
     * Atualizar configurações de email (salva no banco de dados)
     */
    updateEmailConfig(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
}
//# sourceMappingURL=configurations.controller.d.ts.map