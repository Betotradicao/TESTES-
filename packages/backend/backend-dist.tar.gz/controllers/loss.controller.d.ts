import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare class LossController {
    /**
     * Upload e importação de arquivo de perdas
     */
    static upload(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Listar todos os lotes
     */
    static getAllLotes(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Buscar perdas de um lote específico
     */
    static getByLote(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Buscar dados agregados por seção
     */
    static getAggregatedBySection(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Deletar lote
     */
    static deleteLote(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Buscar resultados agregados com filtros
     */
    static getAgregated(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Alternar motivo ignorado
     */
    static toggleMotivoIgnorado(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Listar motivos ignorados
     */
    static getMotivosIgnorados(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Buscar seções únicas para filtro
     */
    static getSecoes(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Buscar produtos únicos para filtro
     */
    static getProdutos(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
}
//# sourceMappingURL=loss.controller.d.ts.map