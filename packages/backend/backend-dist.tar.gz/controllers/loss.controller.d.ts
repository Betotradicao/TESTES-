import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare class LossController {
    /**
     * Helper para obter company_id do usuário logado
     * Busca no banco se não estiver no token JWT
     */
    private static getCompanyId;
    /**
     * Upload e importação de arquivo de perdas
     */
    static upload(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Listar todos os lotes
     */
    static getAllLotes(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Buscar perdas de um lote específico
     */
    static getByLote(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Buscar dados agregados por seção
     */
    static getAggregatedBySection(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Deletar lote
     */
    static deleteLote(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Buscar resultados agregados com filtros
     */
    static getAgregated(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Alternar motivo ignorado
     */
    static toggleMotivoIgnorado(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Listar motivos ignorados
     */
    static getMotivosIgnorados(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Buscar seções únicas para filtro
     */
    static getSecoes(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Buscar produtos únicos para filtro
     */
    static getProdutos(req: AuthRequest, res: Response): Promise<void>;
}
//# sourceMappingURL=loss.controller.d.ts.map