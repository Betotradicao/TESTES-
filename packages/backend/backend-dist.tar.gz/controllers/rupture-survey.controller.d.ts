import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare class RuptureSurveyController {
    /**
     * Upload de arquivo CSV e criação de pesquisa
     */
    static uploadAndCreate(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Listar todas as pesquisas
     */
    static getAll(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Buscar pesquisa por ID com estatísticas
     */
    static getById(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Iniciar pesquisa (mudar para em_andamento)
     */
    static startSurvey(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Atualizar status de um item (usado pelo mobile)
     */
    static updateItemStatus(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Deletar pesquisa
     */
    static deleteSurvey(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Buscar resultados agregados com filtros
     */
    static getAgregated(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
    /**
     * Buscar produtos únicos para filtro
     */
    static getProdutos(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Buscar fornecedores únicos para filtro
     */
    static getFornecedores(req: AuthRequest, res: Response): Promise<void>;
    /**
     * Finalizar auditoria e enviar relatório para WhatsApp
     */
    static finalizeSurvey(req: AuthRequest, res: Response): Promise<void>;
}
//# sourceMappingURL=rupture-survey.controller.d.ts.map