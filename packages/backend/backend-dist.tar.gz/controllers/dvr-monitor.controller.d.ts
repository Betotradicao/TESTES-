/**
 * 🔍 Controller para Monitor de Email DVR
 */
import { Request, Response } from 'express';
/**
 * Testar conexão com DVR
 */
export declare function testarConexaoDVR(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
/**
 * Obter configurações atuais do DVR
 */
export declare function obterConfiguracao(req: Request, res: Response): Promise<void>;
/**
 * Iniciar monitor
 */
export declare function iniciarMonitor(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
/**
 * Parar monitor
 */
export declare function pararMonitor(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
/**
 * Obter status e estatísticas do monitor
 */
export declare function statusMonitor(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
/**
 * Forçar verificação manual
 */
export declare function verificarAgora(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
/**
 * Salvar configuração de senha do Gmail
 */
export declare function salvarSenhaGmail(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
/**
 * Salvar configurações do DVR
 */
export declare function salvarConfigDVR(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
/**
 * Obter stream da câmera
 * Converte RTSP para formato web-compatível (MJPEG snapshot)
 */
export declare function getCameraStream(req: Request, res: Response): Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=dvr-monitor.controller.d.ts.map